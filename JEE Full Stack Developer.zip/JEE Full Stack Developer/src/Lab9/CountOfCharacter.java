package Lab9;

import java.util.HashMap;

import java.util.Scanner;

public class CountOfCharacter 
{
	public HashMap countCharacter() 
	{

		int cnt=0;
		System.out.println("Enter the Array : ");
		Scanner sc=new Scanner(System.in);
		String str=sc.next();
		char arr[] = str.toCharArray();
		HashMap<Character,Integer> hashMap=new HashMap<Character,Integer>();
		HashMap<Character,Integer> hm=new HashMap<Character,Integer>();
		for(int i=0;i<arr.length;i++) 
		{
			if(i==0) 
			{
				cnt=1;
			}
			else 
			{
				cnt=0;
			}
			for(int j=1;j<arr.length;j++) 
			{
				if(arr[i]==arr[j])
				{
					cnt++;
				}
			}

			hashMap.put(arr[i],cnt);

		}

		hm.putAll(hashMap);
		return hm;
	}

	public static void main(String[] args) 
	{

		HashMap h;
		CountOfCharacter c=new CountOfCharacter();
		h=c.countCharacter();
		System.out.println(h);
	}

}