package Lab8;
import java.util.Scanner;
import java.util.StringTokenizer;

public class LineIntegers 
{
	public void check()
	{
	
	Scanner sc =new Scanner(System.in);
	System.out.println("Enter the integers : ");
	String st=sc.nextLine();
	String mydelim=" ";
	StringTokenizer str=new StringTokenizer(st,mydelim);
	int n,sum=0,i=0;
	String[] s1=new String[10];
	while(str.hasMoreTokens())
	{
		s1[i]=str.nextToken();
		n=Integer.parseInt(s1[i]);
		System.out.println(n);
		sum=sum+n;
		i++;
	}
	System.out.println("Sum of all integers : "+sum);
	
	
	}
	public static void main(String[] args)
	{
		LineIntegers l=new LineIntegers();
		l.check();
	}

}
