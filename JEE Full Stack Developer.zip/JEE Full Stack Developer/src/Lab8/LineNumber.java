package Lab8;
import java.io.*;
import java.util.*;

public class LineNumber 
{
	public void check() throws IOException
	{
		int c=0;
		FileReader fr=new FileReader("text.txt");
		BufferedReader br=new BufferedReader(fr);
		String t;
		while((t=br.readLine())!=null)
		{
		c++;
		System.out.println(c+t);
		}
		fr.close();
	}	

	public static void main(String[] args) throws IOException
	{
		
		LineNumber l=new LineNumber();
		l.check();
	}	
}

