package Lab8;
import java.io.*;
import java.util.*;
import java.time.*;

public class DateDiff 
{
	public static void main(String[] args) 
	{

		LocalDate d1=LocalDate.now();
		System.out.println(d1);
		LocalTime t1=LocalTime.now();
		System.out.println(t1);
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the date : ");
		int dd=sc.nextInt();
		int mm=sc.nextInt();
		int yy=sc.nextInt();
		System.out.printf("%d %d %d",dd,mm,yy);
		System.out.println("\n");
		LocalDate d2=LocalDate.of(yy, mm, dd);
		Period p=Period.between(d1, d2);
		System.out.println("Difference between two years : "+p);	
	}
}
