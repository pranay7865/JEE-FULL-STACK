package Project;


public class Sea
{
	
	public enum Season{SPRING,SUMMER,WINTER,RAINY}
	
	Season sea;
	
	public Sea(Season sea)
	{
		this.sea=sea;
	}
	
	
	public void tell()
	{
		switch(sea)
		{
		case SPRING:
			System.out.println("Spring Season");
			break;
		case SUMMER:
			System.out.println("Summer Season");
			break;
		case WINTER:
			System.out.println("Winter Season");
			break;
		case RAINY:
			System.out.println("Rainy Season");
			break;
		default:
			System.out.println("Winter is Best");
			break;
		}
	}
	
	public static void main(String[] args)
	{
		
		Sea s=new Sea(Season.SPRING);
		s.tell();
		Sea w=new Sea(Season.RAINY);
		w.tell();
	}
}