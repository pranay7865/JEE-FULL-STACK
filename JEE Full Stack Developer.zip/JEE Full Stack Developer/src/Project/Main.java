package Project;

public class Main extends Abstract implements Interface 
{
	
	@Override
	public void m1() 
	{
		
		
	}

	@Override
	public void m2() 
	{
		
		System.out.println("Interface Method");
	}

	@Override
	public void meth1() 
	{
		
		System.out.println("Abstract Method");
	}

	@Override
	public void meth2() 
	{
		
		
	}
	@Override
	public void add() {
		
		
	}
	public static void main(String[] args) 
	{
		
		Abstract a=new Main();
		((Abstract)a).meth1();
		Interface b=new Main();
		((Interface)b).m2();
		b.show();
		Interface.show1();

	}

}
