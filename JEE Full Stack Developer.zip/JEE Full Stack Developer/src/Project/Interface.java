package Project;

public interface Interface 
{
	abstract void m1();
	abstract void m2();
	void add();
	default void show()
	{
		System.out.println("In Show");
	}
	static void show1()
	{
		System.out.println("In Static Show1");
	}
}
