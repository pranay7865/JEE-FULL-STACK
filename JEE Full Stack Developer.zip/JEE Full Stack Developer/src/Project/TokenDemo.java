package Project;

import java.util.StringTokenizer;

public class TokenDemo 
{
	

	public static void main(String[] args)
	{
		StringTokenizer st=new StringTokenizer("I,am,happy",",");
		while(st.hasMoreTokens())
			System.out.println(st.nextToken());

	}

}
