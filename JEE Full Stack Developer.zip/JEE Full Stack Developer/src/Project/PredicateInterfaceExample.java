package Project;

//It is a functional interface which represents a predicate (boolean)
import java.util.function.Predicate;

public class PredicateInterfaceExample 
{

	public static void main(String[] args) 
	{
		
		//Predicate<Integer> pr = a -> (a>88); //Creating predicate
		
		//System.out.println(pr.test(20)); //Calling Predicate Method
		
		String s="Pranay";
		Predicate<String> pr = a -> (s.length() > 5); //Creating predicate
		
		System.out.println(pr.test(s));
		
	}

}
