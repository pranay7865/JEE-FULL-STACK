package Project;
import java.util.*;

class Employee1
{
	int id;
	String name;
	Employee1(int id,String name)
	{
		this.id=id;
		this.name=name;
	}
	public int getId()
	{
		return id;
	}
	public String getName()
	{
		return name;
	}
	public void setId(int id)
	{
		this.id=id;
	}
	public void setName(String name)
	{
		this.name=name;
	}
}

public class EmployeeSet 
{
	

	public static void main(String[] args) 
	{
		
		HashSet<Employee1> hs=new LinkedHashSet<Employee1>();
		
		Employee1 e1=new Employee1(100,"abc");
		Employee1 e2=new Employee1(101,"xyz");
		
		hs.add(e1);
		hs.add(e2);
		
		for(Employee1 e:hs)
		{
			System.out.println(e.getId());
			System.out.println(e.getName());
		}
	}

}
