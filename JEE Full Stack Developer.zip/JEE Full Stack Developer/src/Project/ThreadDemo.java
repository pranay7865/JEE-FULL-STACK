package Project;

class New_Thread implements Runnable
{
	public void run()
	{
		try
		{
			for(int i=5;i>0;i--)
			{
				System.out.println("Child Thread : "+i);
				Thread.sleep(2000);
			}
		}
		catch(InterruptedException e)
		{
			System.out.println("Child Interrupted.");
		}
		System.out.println("Exiting Child Thread.");
	}
}
public class ThreadDemo
{
	public static void main(String[] args) 
	{
		New_Thread obj=new New_Thread();
		
		Thread t=new Thread(obj);
		
		t.start();
		System.out.println("State of Thread t "+t.getState());
		
		try
		{
			for(int i=5;i>0;i--)
			{
				System.out.println("Main Thread : "+i);
				Thread.sleep(400);
			}
		
			t.join();
		}
		catch(InterruptedException e)
		{
			System.out.println("Main Thread Interrupted.");
		}
		System.out.println("Main Thread Exiting.");
	}
}
