package Project;


import java.util.function.Predicate;

interface MaxFinderTest
{
	public int maximum(int num1,int num2);

}

	public class MaxFinder
	{
		public static void main(String[] args)
		{
			MaxFinderTest obj = (int num1,int num2)->
			{
				int max=num1>num2?num1:num2;
				return max;
				
			};
			int result=obj.maximum(900,600);
			System.out.println(result);
			

		}

	}




	