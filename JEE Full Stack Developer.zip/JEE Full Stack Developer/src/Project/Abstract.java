package Project;

public abstract class Abstract 
{
	public abstract void meth1();
	
	
	public abstract void meth2();
	
	
		
}
