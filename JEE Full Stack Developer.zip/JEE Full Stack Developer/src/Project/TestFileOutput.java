package Project;
import java.util.*;
import java.io.*;

public class TestFileOutput
{
	public static void main(String[] args)
	{
		byte b[]=new byte[100];
		String ch=" ";
		try
		{
			//System.in.read(b);
			Scanner sc=new Scanner(System.in);
			//FileOutputStream fout=new FileOutputStream("text.txt");
			FileOutputStream fout=new FileOutputStream("text1.txt",true);
			
			ch=sc.nextLine();
			fout.write(ch.getBytes());
			fout.write("\r\n".getBytes());
			
			//fout.write(b);
			fout.close();
			
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
	}
}