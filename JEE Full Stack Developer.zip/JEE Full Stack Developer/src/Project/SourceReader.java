package Project;
import java.io.*;

public class SourceReader 
{

	public static void main(String[] args) 
	{
		try
		{
			FileReader file=new FileReader("text.txt");
			BufferedReader buff=new BufferedReader(file);
			boolean eof=false;
			while(eof!=true)
			{
				String line=buff.readLine();
				if(line==null)
				{
					eof=true;
				}
				else
				{
					System.out.println(line);
				}
			}
			buff.close();
		}
		
		catch(IOException e)
		{
			e.printStackTrace();
		}

	}

}
