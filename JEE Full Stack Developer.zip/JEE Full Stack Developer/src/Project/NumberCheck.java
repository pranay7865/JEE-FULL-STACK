package Project;


import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class NumberCheck 
{

	public static void main(String[] args) 
	{
		Pattern pattern=Pattern.compile("[0-9]{3}");
		
		Matcher matcher=pattern.matcher("143");
		System.out.println(matcher.matches());

	}

}
