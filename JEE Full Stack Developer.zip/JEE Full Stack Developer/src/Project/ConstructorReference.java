package Project;
import java.util.function.*;

public class ConstructorReference 
{

	public static void main(String[] args) 
	{
		Supplier<Item> s1=Item::new;
		
		System.out.println(s1.get());
		
		BiFunction<String,Integer,Item> f=Item :: new;
		Item item=f.apply("xyz", 12);
		System.out.println(item);

	}

}
