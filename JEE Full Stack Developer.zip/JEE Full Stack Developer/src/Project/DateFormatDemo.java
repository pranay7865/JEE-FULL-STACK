package Project;

import java.util.*;
import java.text.*;
import java.io.*;

public class DateFormatDemo 
{
	

	public static void main(String[] args) 
	{
		
		Date d=new Date();
		System.out.println(d);
		
		DateFormat dt=DateFormat.getDateInstance(DateFormat.LONG);
		System.out.println(dt.format(d));
		DateFormat germanDate=DateFormat.getDateInstance(DateFormat.LONG, Locale.GERMAN);
		System.out.println(germanDate.format(d));
		
		SimpleDateFormat sdf=new SimpleDateFormat("dd MM YY ");
		System.out.println(sdf.format(d));
		
		
	}

}