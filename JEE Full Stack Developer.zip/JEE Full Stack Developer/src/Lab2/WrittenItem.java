package Lab2;

public class WrittenItem extends Item
{
	private String author;

	@Override
	public String toString() 
	{
		// TODO Auto-generated method stub
		return null;
	}
 
	@Override
	public void checkIn() 
	{
		// TODO Auto-generated method stub
		System.out.println("Check In");
	}

	@Override
	public void checkOut() 
	{
		// TODO Auto-generated method stub
		System.out.println("Check Out");
	}

	@Override
	public void print() 
	{
		// TODO Auto-generated method stub
		System.out.println("Author Name : "+author);
	}

	@Override
	public void addItem() 
	{
		// TODO Auto-generated method stub
		
	}

	@Override
	public void add() {
		// TODO Auto-generated method stub
		
	}

	public String getAuthor()
	{
		return author;
	}
	public void setAuthor(String author)
	{
		this.author=author;
	}


}
