package Lab2;

public class Video
{
	private String videoName,director, genre;
	private int year;
	
	public Video()
	{
		
	}
	public String toString()
	{
		return videoName;
	}
	
	public String getDirector()
	{
		return director;
	}
	public void setDirector(String director)
	{
		this.director=director;
	}
	
	public int getYear()
	{
		return year;
	}
	public void setYear(int year)
	{
		this.year=year;
	}
	
	public String getGenre()
	{
		return genre;
	}
	public void setGenre(String genre)
	{
		this.genre=genre;
	}
	
	
	/*public static void main(String[] args)
	{
		Video b=new Video("Friendship");
		b.checkIn();
		b.setDirector("Manish Deshmukh");
		b.setGenre("Thriller");
		b.setYear(2019);
		System.out.println("Video Name : "+b);
		b.print();
		b.checkOut();
	}
	*/
}
