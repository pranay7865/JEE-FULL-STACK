package Lab2;

public class Main 
{
	 
	public static void main(String[] args) 
	{
		Book b=new Book();
		JournalPaper j=new JournalPaper();
		Video v=new Video();
		CD c=new CD();
		WrittenItem w=new WrittenItem();
		Item a=new WrittenItem();
		w.setAuthor("Pranay");
		a.setCopies(5);
		v.setYear(2011);
		j.setTitle("Fire and Ice");
		v.setDirector("R R Martin");
		j.setIdNo(123);
		c.setArtist("Martin");
		System.out.println("Title name : "+j.getTitle());
		System.out.println("Number of Copies : "+a.getCopies());
		System.out.println("Year : "+v.getYear());
		System.out.println("Name : "+w.getAuthor());
		System.out.println("Director Name : "+v.getDirector());
		System.out.println("Id no. : "+j.getIdNo());
		System.out.println("Artist Name : "+c.getArtist());
	}

}
