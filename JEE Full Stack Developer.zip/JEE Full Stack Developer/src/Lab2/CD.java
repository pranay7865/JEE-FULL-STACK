package Lab2;

public class CD  
{
	private String artist, genre,CdName;
	public CD()
	{
		
	}
	public String toString()
	{
		return CdName;
	}
	
	public String getArtist()
	{
		return artist;
	}
	public void setArtist(String artist)
	{
		this.artist=artist;
	}
	
	public String getGenre()
	{
		return genre;
	}
	public void setGenre(String genre)
	{
		this.genre=genre;
	}
	
	
}
