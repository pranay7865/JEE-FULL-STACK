package Lab2;

import Lab2.Item;

public abstract class MediaItem extends Item 
{ 
	private int runtime,year;
	private String director,genre;
	
	public void setDirector(String director)
	{
		this.director=director;
	}
	public void getDirector(String director)
	{
		this.director=director;
	}
	public int getRuntime()
	{
		return runtime;
	}
	public void setRuntime(int runtime)
	{
		this.runtime=runtime;
	}
	
	
}