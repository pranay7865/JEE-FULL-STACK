package Lab2;

public class JournalPaper extends WrittenItem
{
	private static int year;
	private String journalName;
	
	public String journalName() 
	{
		return journalName;
	}
	public void journalName(String journalName)
	{
		this.journalName=journalName;
	}
	public String toString()
	{
		return journalName;
	}
	
	public int getYear()
	{
		return year;
	}
	
	public void setYear(int year)
	{
		this.year=year;
	}
	
	
	
}
