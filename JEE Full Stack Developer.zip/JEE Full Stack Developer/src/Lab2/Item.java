package Lab2;

public abstract class Item 
{
	private int idno,copyno;
	private String title;
	
	public Item()
	{
		//System.out.println("Default");
	}
	
	public int getIdNo()
	{
		return idno;
	}
	public void setIdNo(int idno)
	{
		this.idno=idno;
	}
	public String getTitle()
	{
		return title;
	}
	public void setTitle(String title)
	{
		this.title=title;
	}
	
	
	public abstract String toString();
	public abstract void add();
	public abstract void print();
	
	public int getCopies()
	{
		return copyno;
	}
	public void setCopies(int copyno)
	{
		this.copyno=copyno;
	}
	
	public void addItem() {
		// TODO Auto-generated method stub
		
	}

	public void checkIn() {
		// TODO Auto-generated method stub
		
	}

	public void checkOut() {
		// TODO Auto-generated method stub
		
	}
	
	
}
