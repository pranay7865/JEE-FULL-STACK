package Lab5;
import java.util.*;

public class Prime 
{
	int cnt,m;
	public void check()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Number");
		int n=sc.nextInt();
		for(int i=2;i<n;i++)
		{
			m=i;
			cnt=0;
			for(int j=2;j<i;j++)
			{
				if(m%j==0)
				{
					cnt=1;
					break;
				}
			}
			if(cnt==0)
				System.out.println(""+m);
		}
	}
	
	public static void main(String[] args) 
	{
		Prime p=new Prime();
		p.check();

	}

}
