package Lab5;
import java.util.*;
class Emp extends Exception
{
	
}
public class Employee 
{
	public void check()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the amount");
		int sal=sc.nextInt();
		try
		{
			if(sal<3000)
			{
				throw new Emp();
			}
			else
			{
				System.out.println("Sufficient Balance");
			}
		}
		catch(Emp e)
		{
			System.out.println("Balance need to be more");
		}
	}
	public static void main(String[] args)
	{
		Employee a=new Employee();
		a.check();
	}	
}
