package Lab5;
import java.util.*;

public class Fibonacci1 
{
	static int n1=1,n2=1,n3=0;
	static int fibo(int count) 
	{
		n3=n1+n2;
		n1=n2;
		n2=n3;
		if(count>0)
		{
			fibo(count-1);
			return n3;
		}
		else
			return 0;
	}

	public static void main(String[] args) 
	{
		int n;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Nth Number");
		n=sc.nextInt();
		Fibonacci1 f=new Fibonacci1();
		int num=Fibonacci1.fibo(n-3);
		System.out.println(num);
		

	}

	

}
