package Lab5;

import java.util.Scanner;

public class Fibonacci 
{
	
	public void fibo()
	{
		//Without Recursion
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Nth number");
		int n=sc.nextInt();
		 int n1=1,n2=1,n3,i;    
		 for(i=2;i<n;i++) 
		 {    
		  n3=n1+n2;    
		     
		  n1=n2;    
		  n2=n3;  
		   
		 }
		 System.out.print("Without Recursion : "+n2);
	}
	
	
	//With Recursion
	static int n4=1,n5=1,n6=0;
	static int fibo1(int count) 
	{
		n6=n4+n5;
		n4=n5;
		n5=n6;
		if(count>0)
		{
			fibo1(count-1);
			return n6;
		}
		else
			return 0;
	}
	
	
	public static void main(String[] args) 
	{
		
		Fibonacci f=new Fibonacci();
		f.fibo();
		int n;
		Scanner sc=new Scanner(System.in);
		System.out.println("\nEnter Nth Number");
		int n1=sc.nextInt();
		Fibonacci f1=new Fibonacci();
		int num=Fibonacci.fibo1(n1-3);
		System.out.println("With Recursion : "+num);
	}

}
