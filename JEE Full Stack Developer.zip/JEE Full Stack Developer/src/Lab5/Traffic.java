package Lab5;

import java.util.Scanner;

public class Traffic 
{
	public void Select()
	{
		System.out.println("1.Red\n2.Yellow\n3.Green");
		System.out.println("Please select your choice");
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		if(n==1)
			System.out.println("Stop");
		else
			if(n==2)
				System.out.println("Ready");
			else
				if(n==3)
					System.out.println("Go");
				else
					System.out.println("Inappropriate Choice");
		
	}

	public static void main(String[] args) 
	{
		Traffic t=new Traffic();
		t.Select();
	}

}
