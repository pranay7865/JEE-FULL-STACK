package Lab11;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class ConcurrentCopyDataThread implements Runnable
{

	public static void main(String args[])
	{

		Executor ex= Executors.newSingleThreadExecutor();
		Runnable task= new ConcurrentCopyDataThread();
		System.out.println("Copying Data using Executor :");
		ex.execute(task);
	}

	@Override
	public void run() 
	{
		try
		{
			FileReader fr= new FileReader("C:\\Users\\pransont\\Eclipse Programs\\JEE Full Stack Developer\\src\\Lab11\\Source.txt");
			BufferedReader br= new BufferedReader(fr);
			FileWriter fw= new FileWriter("C:\\Users\\pransont\\Eclipse Programs\\JEE Full Stack Developer\\src\\Lab11\\Target.txt");
			BufferedWriter bw= new BufferedWriter(fw);
			String s;
			boolean eof=false;
			while (eof!=true)
			{
				s= br.readLine();
				if (s==null)
				{
					eof=true;
				}
				else
				{
					char []arr=s.toCharArray();
					int cnt=0;
					int j=0;
					while(j<arr.length)
					{
						if(cnt!=10)
						{
							System.out.println(arr[j]);
							cnt++;
						}
						bw.write(arr[j]);
						if(cnt%10==0)
						{
							System.out.println("10 characters copied");
							cnt++;
						}
						j++;
						Thread.sleep(5000);
					}
				}
			}
			System.out.println("exit");
			br.close();
			bw.close();
		}
		catch(InterruptedException e)
		{
			System.out.println(e);
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
	}

}
