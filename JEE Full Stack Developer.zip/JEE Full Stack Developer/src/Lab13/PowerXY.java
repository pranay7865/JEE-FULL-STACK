package Lab13;
import java.util.function.Function;

interface power
{
	public int power1(int x,int y);
}

public class PowerXY 
{
	public static void main(String[] args) 
	{
		power obj = (int x,int y)->
		{
			int r =1;
			for(int i=1;i<=y;i++)
			{
				r=r*x;
			}
			return r;		
		};
		int result = obj.power1(2, 4);
		System.out.println("X^Y : " +result);
	}
}
