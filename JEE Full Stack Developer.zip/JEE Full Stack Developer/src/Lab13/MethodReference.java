package Lab13;

import java.util.function.BiFunction;
import java.util.function.Supplier;

public class MethodReference 
{
		private String name;
		private double price;
		
		public MethodReference()
		{
			name="Apple";
			price=20.0;
		}
		
		public MethodReference(String name,double price)
		{
			this.name=name;
			this.price=price;
		}
		
		public String getName()
		{
			return name;
		}
		
		public void setName(String name)
		{
			this.name=name;
		}
		
		public double getPrice()
		{
			return price;
		}
		
		public void setPrice(double price)
		{
			this.price=price;
		}
		
		@Override
		public String toString()
		{
			return "Item [Name = "+name+",Price = "+price+"]";
		}

}
