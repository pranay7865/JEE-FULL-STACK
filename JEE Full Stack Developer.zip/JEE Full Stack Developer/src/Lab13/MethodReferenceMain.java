package Lab13;

import java.util.function.BiFunction;
import java.util.function.Supplier;

public class MethodReferenceMain 
{

	public static void main(String[] args) 
	{
		Supplier<MethodReference> s1=MethodReference::new;
		
		System.out.println(s1.get());
		
		BiFunction<String,Integer,MethodReference> f=MethodReference :: new;
		MethodReference item=f.apply("Grapes", 12);
		System.out.println(item);


	}

}
