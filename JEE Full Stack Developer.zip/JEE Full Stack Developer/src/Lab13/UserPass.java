package Lab13;
import java.util.*;
import java.util.function.BiFunction;


public class UserPass 
{

	public static void main(String[] args) 
	{
		
		BiFunction <String,String,Boolean> f=(u,p) ->
		{
			if(u.equals("admin") && (p.equals("abc")))
				return true;
			else
				return false;
		};
		System.out.println(f.apply("admin","abc"));
		
	}

}

