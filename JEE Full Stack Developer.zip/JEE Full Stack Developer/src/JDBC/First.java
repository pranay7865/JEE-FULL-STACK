package JDBC;


import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.*;

public class First 
{
	public static void main(String[] args)
	{
		/*int count=0,i=0;
		do
		{
			count+=1;
			i++;
			System.out.println(i+" ");
		}*/
		
		Connection c=null;
		Statement stmt=null;
		ResultSet rs=null;
		
		try
		{
			c=CommonCon.getCon();
			
			stmt=c.createStatement();
			rs=stmt.executeQuery("Select Student_Code,Student_Name from Student_Master");
			while(rs.next())
			{
				System.out.println(rs.getInt(1)+ " "+rs.getString(2));
			};
		}
		catch(SQLException e)
		{
			System.out.println(e);
		}
		finally
		{
			try
			{
				c.close();
				rs.close();
				stmt.close();
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
		}
	}
}
