package JDBC;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;

public class Eight 
{

	public static void main(String[] args) throws Exception
	{
		try
		{
			Class.forName("oracle.jdbc.OracleDriver");
			Connection c=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","System","India123");
			System.out.println("Connected");
			
			CallableStatement cs=c.prepareCall("{call proc}");
			cs.execute();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}

	}

}
