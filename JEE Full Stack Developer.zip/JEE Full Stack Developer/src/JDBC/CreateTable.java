package JDBC;

import java.sql.*;

public class CreateTable 
{

	public static void main(String[] args) 
	{
		System.out.println("Table Creation Example");
		try
		{
			Class.forName("oracle.jdbc.OracleDriver");
			Connection c=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","System","India123");
			
			try
			{
				Statement st=c.createStatement();
				String table="CREATE TABLE Emp(Emp_code number(2),Emp_name varchar2(20)";
				st.execute(table);
			}
			catch(SQLException s)
			{
				System.out.println("Table already exists");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
