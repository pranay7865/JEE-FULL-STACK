package JDBC;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.*;

public class Prep 
{
	public static void main(String[] args)
	{
	Connection c=null;
	try
	{
		Class.forName("oracle.jdbc.OracleDriver");
		c=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","System","India123");
		
		//c.setAutoCommit(false);
		//PreparedStatement pst = c.prepareStatement("Insert into Trial_new (eno,ename)"+"values(?,?)");
		
		//PreparedStatement pst=c.prepareStatement("Update Trial set ename=? where eno=?");
		
		PreparedStatement pst=c.prepareStatement("Delete from Trial where ename=? ");
		
		//pst.setInt(1,Integer.parseInt(args[0]));
		//pst.setString(2,args[1]);
		pst.setString(1,args[0]);
		//pst.setInt(2,Integer.parseInt(args[1]));
		
		//pst.setInt(3,Integer.parseInt(args[2]));l
		
		pst.executeUpdate();
		
		//c.roolback;
		//commit;
		//pst.close();
		
		/*pst=c.prepareStatement("select * from Trial");
		ResultSet rs=pst.executeQuery();
		while(rs.next())
		{
			System.out.println(rs.getInt(0));	
		}
		 */		
		c.close();
		
	}
	catch(Exception e)
	{
		System.out.println(e);
	}
	}

}
