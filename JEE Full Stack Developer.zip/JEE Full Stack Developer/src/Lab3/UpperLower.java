package Lab3;

import java.util.Scanner;

public class UpperLower 
{
	

	public void calculation() 
	{
		int n;
		String temp;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number of names : ");
		n=sc.nextInt();
		String names[]=new String[n];
		String names1[]=new String[n];
		Scanner sc1=new Scanner(System.in);
		System.out.println("Enter the names : ");
		for(int i=0;i<n;i++)
		{
			names[i]=sc1.next();
		}
		for(int i=0;i<n;i++)
		{
			for(int j=i+1;j<n;j++)
			{
				if(names[i].compareTo(names[j])>0)
				{
					temp=names[i];
					names[i]=names[j];
					names[j]=temp;
				}
					
			}
		}
		System.out.println("Names in sorted order : ");
		for(int i=0;i<n;i++)
		{
			System.out.print(names[i] + " ");
		}
		if((n%2)==0)
		{
			for(int i=0;i<(n/2);i++)
			{
				names1[i]=names[i].toUpperCase();
			}
			for(int j=(n/2);j<n;j++)
			{
				names1[j]=names[j].toLowerCase();
			}
		}
		else 
		{
			for(int i=0;i<(n/2)+1;i++)
			{
				names1[i]=names[i].toUpperCase();
			}
			for(int j=(n/2)+1;j<n;j++)
			{
				names1[j]=names[j].toLowerCase();
			}
		}
		System.out.println("\nNames in sorted order : ");
		for(int i=0;i<n;i++)
		{
			System.out.print(names1[i] + "  ");
		}
	}
	public static void main(String[]args) {
		UpperLower u= new UpperLower();
		u.calculation();
	}
}
