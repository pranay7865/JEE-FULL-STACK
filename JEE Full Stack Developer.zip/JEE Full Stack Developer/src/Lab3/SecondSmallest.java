package Lab3;

import java.util.*;

public class SecondSmallest 
{
	int []arr;
	public int getSecondSmallest(int []arr)
	{
		Arrays.sort(arr);
		return arr[1];
	}

	public static void main(String[] args) 
	{
		int i,n;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the size of array : ");
		n=sc.nextInt();
		System.out.println("Enter the array : ");
		int arr[]=new int[n];
		for(i=0;i<n;i++)
		{
			arr[i]=sc.nextInt();
		}
		SecondSmallest s=new SecondSmallest();
		int scndSmall=s.getSecondSmallest(arr);
		System.out.println(scndSmall);
	}

}
