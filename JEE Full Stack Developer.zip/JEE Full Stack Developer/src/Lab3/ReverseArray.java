package Lab3;

import java.lang.*;
import java.util.*;

public class ReverseArray 
{
	public void calculation()
	{
		int sum=0;
		System.out.println("Enter the number of array : ");
		Scanner sc =new Scanner(System.in);
		int n=sc.nextInt();
		int []arr= new int[n];
		System.out.println("Enter the elements of array : ");
		for(int i=0;i<n;i++)
		{
			arr[i]=sc.nextInt();
		}
		for(int i=0;i<arr.length;i++)
		{
			sum=0;
			while(arr[i]!=0)
			{
				int rem=arr[i]%10;
				arr[i]=arr[i]/10;
				sum=sum*10+rem;
			}
			arr[i]=sum;                  
		}
		Arrays.sort(arr);
		for(int i=0;i<arr.length;i++)
		{
			System.out.println(" "+arr[i]);
		}
	}

	public static void main(String[] args) 
	{
		ReverseArray r=new ReverseArray();
		r.calculation();

	}

}
