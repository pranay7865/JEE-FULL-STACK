package Lab3;

import java.util.*;

public class CountChar 
{
	public void count()
	{
		int i=0,j,cnt=0;
		System.out.println("Enter the string : ");
		Scanner sc =new Scanner(System.in);
		String str=sc.next();
		char arr[]=str.toCharArray();
		for(i=0;i<arr.length;i++)
		{
			System.out.println(arr[i]);
		}
		for(i=0;i<arr.length;i++)
		{
			cnt=0;
			for(j=0;j<arr.length;j++)
			{
				if(arr[i]==arr[j])
				{
					cnt++;
				}
			}
			System.out.println(arr[i]+" varible comes "+cnt);
		}
	}

	public static void main(String[] args) 
	{
		CountChar c=new CountChar();
		c.count();
	}

}
