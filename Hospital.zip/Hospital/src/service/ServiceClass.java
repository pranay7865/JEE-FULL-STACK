package service;

import java.util.regex.Pattern;

import Exception.HOSException;
import bean.Hospital;
import dao.DaoClass;
import dao.DaoInterface;

public class ServiceClass implements ServiceInterface, DaoInterface {
	
	DaoClass daoClass= new DaoClass();
	

	@Override
	public int addPatient(Hospital hospital) throws HOSException {
		return daoClass.addPatient(hospital);
	}

	@Override
	public Hospital getPatientdetails(int patientId) throws HOSException {
		return daoClass.getPatientdetails(patientId);
	}
	
	public void validateId(int id) throws HOSException {
		String idRegEx = "[0-9]";
		if (!Pattern.matches(idRegEx, String.valueOf(id)) == false) {
			throw new HOSException("Id should be  digit ");
		}
	}
	
	public void validateName(String name) throws HOSException {
		String nameRegEx = "[a-zA-Z ]+";
		if (!Pattern.matches(nameRegEx, name)) {
			throw new HOSException("Name should contain only alphabet");
		}
	}

	@Override
	public void validateFees(double doctorFees) throws HOSException {
		String feesRegEx = "[0-9]";
		if (!Pattern.matches(feesRegEx, String.valueOf(doctorFees)) == false) {
			throw new HOSException("Id should be  digit ");
		}
	}

}

	



