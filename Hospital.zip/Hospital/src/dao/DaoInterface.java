package dao;

import Exception.HOSException;
import bean.Hospital;

public interface DaoInterface
{
	int addPatient(Hospital hospital)throws HOSException;
	
	public  Hospital getPatientdetails(int patientId) throws HOSException;
	
}