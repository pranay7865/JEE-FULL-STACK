package Exception;

public class HOSException extends Exception {
	public HOSException(String message)
	{
		super(message);
	}

}
