package com.cg.lms.DAO;

public interface LMSInterface {

}
