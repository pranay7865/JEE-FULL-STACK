package com.cg.lms.DAO;

import java.awt.List;
import java.util.ArrayList;

import com.cg.lms.Bean.Book;
import com.cg.lms.Exception.LMSException;
import com.cg.lms.Util.LMSUtil;

public class LMSDAO implements LMSInterface{

	public Book searchBookName(String availBookName) throws LMSException {
		ArrayList<Book> list1= LMSUtil.getList();
		Book bookData=null;
		boolean flag=false;
		for(Book book:list1){
		if(book.getBookName().equalsIgnoreCase(availBookName))
		{
			bookData=book;
			flag=true;
			break;
		}
		}
	if(flag==false)
	{
		throw new LMSException("This Book is not available");}
	
		
	
		return bookData;
	}

	public ArrayList<Book> getAllBooks() {
		// TODO Auto-generated method stub
		return LMSUtil.getList();
	}

	public Book addBook(Book book) throws LMSException{
		
		ArrayList<Book> list1=LMSUtil.getList();
		list1.add(book);
		//System.out.println(list1+"");
		//return id;
		return book;
		
	}

	public Book removeBookName(Book deleteBook) throws LMSException {
		
		ArrayList<Book> list1=LMSUtil.getList();
		for(Book delb:list1){
		if(delb.getBookName().equals(deleteBook.getBookName()))
		list1.remove(deleteBook);
		}
	
		//System.out.println(list1+"");
		return deleteBook;
		
		
		
	}
}
