package com.cg.emp.util;

import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import com.cg.emp.entity.Employee;

public class CollectionUtil {
private static HashMap<Integer,Employee> empmap=new HashMap<>();
private static ArrayList<Employee> empset=new ArrayList<Employee>();
static{
	empset.add(new Employee(1001,"Rkreddy",45000.0f,LocalDate.of(2019,Month.JANUARY,8)));
	empset.add(new Employee(1002,"sri",44000.0f,LocalDate.of(2019,Month.FEBRUARY,9)));
	empset.add(new Employee(1003,"vijay",43000.0f,LocalDate.of(2019,Month.MARCH,10)));
	empset.add(new Employee(1004,"uday",42000.0f,LocalDate.of(2019,Month.APRIL,11)));
	empset.add(new Employee(1005,"russelmama",41000.0f,LocalDate.of(2019,Month.MAY,12)));
	
	empmap.put(1001,new Employee(1001,"Rkreddy",45000.0f,LocalDate.of(2019,Month.JANUARY,8)));;
	empmap.put(1002,new Employee(1002,"sri",44000.0f,LocalDate.of(2019,Month.FEBRUARY,9)));
	empmap.put(1003,new Employee(1003,"vijay",43000.0f,LocalDate.of(2019,Month.MARCH,10)));
	empmap.put(1004,new Employee(1004,"uday",42000.0f,LocalDate.of(2019,Month.APRIL,11)));
	empmap.put(1005,new Employee(1005,"russelmama",41000.0f,LocalDate.of(2019,Month.MAY,12)));
}
	public static int addEmp(Employee emp){
		empmap.put(emp.getEmpid(), emp); // Abhishek - instead of null add employee id for newly added employee. Null key will not be useful while searching the user in map.
		return emp.getEmpid();
	}	
	public static List<Map.Entry<Integer, Employee>> fetchAllEmp(){
		// Abhishek - First sort the employees in ascending order then return it to main method. empmap will return the employees added in the sequence.
		HashMap<Integer,Employee> empmap1=new HashMap<>();
		List<Map.Entry<Integer, Employee>> entryList = new ArrayList<Map.Entry<Integer, Employee>>(empmap.entrySet());

	        Collections.sort(
	                entryList, new Comparator<Map.Entry<Integer, Employee>>() {
	            @Override
	            public int compare(Map.Entry<Integer, Employee> e1, Map.Entry<Integer, Employee> e2) {
	                return e1.getValue().getEmpname().compareTo(e2.getValue().getEmpname());
	            }
	        }
	     );
	        /*for (int i = 0; i < entryList.size(); i++) {
	        	empmap1.put(entryList.get(i).getValue().getEmpid(), entryList.get(i).getValue());
			}*/
	        
		//System.out.println(entryList);
		return entryList;
	}
	public static Employee getEmpById(int empId){
		Employee emp=empmap.get(empId);
		return emp;
	}
	
public static ArrayList<Employee> searchEmpByName(String empName) {
	//Collections.sort(empset,Employee.getCompByName()); // old code
	/* Abhishek - Newly added start */
	ArrayList<Employee> empList = new ArrayList<Employee>();
	for (Employee employee : empset) {
		if (employee.getEmpname().trim().toLowerCase().equalsIgnoreCase(empName.trim())) {
			empList.add(employee);
		}
	}
	/* Abhishek - Newly added end */
	return empList;
}
public static int deleteEmp(int empId){
	empmap.remove(empId);
	for(Entry<Integer, Employee> m:empmap.entrySet()){    
	       System.out.println(m.getKey()+" "+m.getValue());    
	} 
	return empId;
	
}
public static Employee updateEmp(int empId, String newName, float newSal) {
	// TODO Auto-generated method stub
	//Employee emp=empmap.put(empId,new Employee(empId, newName,newSal, null)); 
	empmap.put(empId,new Employee(empId, newName,newSal, empmap.get(empId).getEmpdoj())); // Abhishek - changed for doj to make the object equal while adding to map
	Employee emp= empmap.get(empId); // Abhishek - after adding the updated value of employee, get the employee object.
	return emp;
}
}
