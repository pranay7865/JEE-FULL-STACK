package com.cg.emp.dao;
	import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map.Entry;

import com.cg.emp.entity.Employee;
import com.cg.emp.exception.EmployeeException;
	
	public interface EmployeeDao {	
		
	public int addEmployee(Employee ee)throws EmployeeException;
	public List<Entry<Integer, Employee>> fetchAllEmp(); // Abhishek - return type changed to List
	public Employee getEmpById(int empId);
	public ArrayList<Employee> searchEmpByName(String name);
	public int deleteEmp(int empId);
	public Employee updateEmp(int empId, String newName, float newSal);
	}

