package ui;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

import beans.Book;
import beans.Student;
import exception.LibraryException;
import service.ILibraryService;
import service.LibraryService;

public class Client {

	public static void main(String[] args) {
		
		ILibraryService service = new LibraryService();
		//Book book = new Book();
		Student student = new Student();
		Scanner scanner = null;
		String continueChoice="";
		boolean continueFlag=false;
		do
		{
			System.out.println("*******Novel Library Management System*******");
			System.out.println("1)Issue Book");
			System.out.println("2)Display All Books");
			System.out.println("3)Add Book");
			System.out.println("4)Exit");
			int choice=0;
			boolean choiceFlag=false;
			do 
			{
				scanner=new Scanner(System.in);
				System.out.println("Enter your choice :-");
				try {
					choice=scanner.nextInt();
					choiceFlag=true;
					
					switch (choice) 
					{
					case 1:
						String studentRollNo="";
						boolean studentRollNoFlag=false;
						do {
							System.out.println("Enter your 5 Digits Roll No :");
							scanner=new Scanner(System.in);
							try {
								studentRollNo=scanner.nextLine();
								service.validateRollNo(studentRollNo);
								studentRollNoFlag=true;
								break;
							}catch(LibraryException e)
							{
								studentRollNoFlag=false;
								System.err.println(e.getMessage());
							}
						} while (!studentRollNoFlag);
						
						String studentName="";
						boolean studentNameFlag=false;
						do {
							System.out.println("Enter your name :");
							scanner=new Scanner(System.in);
							try {
								studentName=scanner.nextLine();
								service.validateName(studentName);
								student.setStudentName(studentName);
								studentNameFlag=true;
								break;
							}catch(LibraryException e)
							{
								studentNameFlag=false;
								System.err.println(e.getMessage());
							}
						} while (!studentNameFlag);
						
						String searchBookName="";
						boolean searchBookNameFlag=false;
						do {
							System.out.println("Enter Book Name :");
							scanner=new Scanner(System.in);
							
							
							Book bookData;
							try {
								searchBookName=scanner.nextLine();
								searchBookNameFlag=true;
								bookData=service.searchBookName(searchBookName);
								System.out.println("Book Issued to : "+student.getStudentName());
								System.out.println(bookData);
								
								break;
							}catch(LibraryException e)
							{
								searchBookNameFlag=false;
								System.err.println(e.getMessage());
							}
						} while (!searchBookNameFlag);
						
						break;
					case 2:
						System.out.println("Books Available in the Novel Library");
						ArrayList<Book> books=null;
						try {
							books=service.getAllBooks();
							for(Book obj : books)
							{
								System.out.println(obj);
							}
							break;
						} catch (LibraryException e) {
							System.err.println(e.getMessage());
						}
						
						break;
						
					case 3:
						System.out.println("Add book in the library : ");
						String newBook="";
						boolean newBookFlag=false;
						do {
							System.out.println("Enter the name of book :");
							scanner=new Scanner(System.in);
							try {
								newBook=scanner.nextLine();
								service.validateNewBook(newBook);
								//book.setBookName(newBook);
								newBookFlag=true;
								break;
							}catch(LibraryException e)
							{
								newBookFlag=false;
								System.err.println(e.getMessage());
							}
						} while (!newBookFlag);
						
						String authorName="";
						boolean authorNameFlag=false;
						do {
							System.out.println("Enter the name of author :");
							scanner=new Scanner(System.in);
							try {
								authorName=scanner.nextLine();
								service.validateAuthor(authorName);
								//book.setAuthorname(authorName);
								authorNameFlag=true;
								break;
							}catch(LibraryException e)
							{
								authorNameFlag=false;
								System.err.println(e.getMessage());
							}
						} while (!authorNameFlag);
						
						
						try { 
							Book book = new Book(newBook,authorName);
							int bookId=(int)(Math.random()*1000);
							book.setBookId(bookId);
							book.setBookName(newBook);
							book.setAuthorname(authorName);
							Book b2=service.addBook(book);
							System.out.println("Book Added with id : "+bookId);
						} catch (LibraryException e) {
							System.err.println(e.getMessage());
						}
						break;
						
					case 4:
						System.out.println("*******Thank You*******");
						System.exit(0);
						break;
						
					default:
						System.out.println("Enter ");
						break;
					}
					
				} catch (InputMismatchException e) {
					System.err.println("Enter digits 1, 2, 3 or 4 only");
				}
			}while(!choiceFlag);
			scanner=new Scanner(System.in);
			System.out.println("Do you want to continue : [Yes/No]");
			continueChoice=scanner.next();
			
		}while(continueChoice.equalsIgnoreCase("yes"));
	}

}
