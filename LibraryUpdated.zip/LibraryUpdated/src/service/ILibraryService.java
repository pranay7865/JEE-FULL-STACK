package service;

import java.util.ArrayList;

import beans.Book;
import exception.LibraryException;

public interface ILibraryService {
	
	public ArrayList<Book> getAllBooks() throws LibraryException;
	
	public Book searchBookName(String searchBookName) throws LibraryException;
	
	public Book addBook(Book book) throws LibraryException;

	public void validateRollNo(String studentRollNo) throws LibraryException;

	public void validateName(String studentName) throws LibraryException;

	public void validateNewBook(String newBook) throws LibraryException;

	public void validateAuthor(String authorName) throws LibraryException;
	
	
	

}
