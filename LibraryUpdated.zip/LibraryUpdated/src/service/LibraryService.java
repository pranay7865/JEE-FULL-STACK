package service;

import java.util.ArrayList;
import java.util.regex.Pattern;

import beans.Book;
import dao.ILibraryDao;
import dao.LibraryDao;
import exception.LibraryException;

public class LibraryService implements ILibraryService{
	
	ILibraryDao dao = new LibraryDao();

	@Override
	public ArrayList<Book> getAllBooks() throws LibraryException {
		
		return dao.getAllBooks();
	}

	@Override
	public Book searchBookName(String searchBookName) throws LibraryException {
		
		return dao.searchBookName(searchBookName);
	}

	@Override
	public Book addBook(Book book) throws LibraryException {
	
		return dao.addBook(book);
	}

	@Override
	public void validateRollNo(String studentRollNo) throws LibraryException {
		String RollNoRegEx = "[0-9]{5}";
		if(!Pattern.matches(RollNoRegEx, String.valueOf(studentRollNo)))
		{
			throw new LibraryException("Roll no consists of digits only");
		}
		
	}

	@Override
	public void validateName(String studentName) throws LibraryException {
		String NameRegEx = "[A-Za-z ]+";
		if(!Pattern.matches(NameRegEx,studentName ))
		{
			throw new LibraryException("Name should contain alphabets only");
		}
	}

	@Override
	public void validateNewBook(String newBook) throws LibraryException {
		String NewRegEx = "[A-Za-z ]+";
		if(!Pattern.matches(NewRegEx,newBook ))
		{
			throw new LibraryException("Name should contain alphabets only");
		}
	}

	@Override
	public void validateAuthor(String authorName) throws LibraryException {
		String AuthorRegEx = "[A-Za-z ]+";
		if(!Pattern.matches(AuthorRegEx,authorName))
		{
			throw new LibraryException("Name should contain alphabets only");
		}
	}

	
	
	
	

}
