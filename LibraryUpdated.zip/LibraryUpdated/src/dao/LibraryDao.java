package dao;

import java.util.ArrayList;
import java.util.Set;

import beans.Book;
import exception.LibraryException;
import util.LibraryUtil;

public class LibraryDao implements ILibraryDao
{
	LibraryUtil libUtil=new LibraryUtil();
	ArrayList<Book> bookEntry = new ArrayList<Book>();
	
	@Override
	public ArrayList<Book> getAllBooks() throws LibraryException 
	{
		return libUtil.getAllBooks();
	}

	@Override
	public Book searchBookName(String searchBookName) throws LibraryException 
	{
		bookEntry =libUtil.getAllBooks();
		Book bookData = null;
		boolean bookFlag=false;
		
		for(Book book : bookEntry)
		{
			if(book.getBookName().equalsIgnoreCase(searchBookName))
			{
				bookData=book;
				bookFlag=true;
				break;
			}
		}
		
		if(bookFlag==false)
		{
			throw new LibraryException("This Book is not available");
		}
		
		return bookData;
	}

	@Override
	public Book addBook(Book book) throws LibraryException {
		
		//int bookId=0;
		//int bookId=book.getBookId();
		//System.out.println(book.getBookId());
		bookEntry = libUtil.getAllBooks();
		bookEntry.add(book);
		
		return book;
	}
	

}
