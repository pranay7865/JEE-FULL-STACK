"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class IProduct {
}
exports.IProduct = IProduct;
exports.company = "capgemini";
