let empId:number;
let empName:string;
let empFeedback:boolean;
let anyType:any;
let myArray:number[]=[1,2,3];
let anyArrayType:any[]=[1,'Rahul',false,true];

empId=1001;
empName="Rahul Vikash";
empFeedback=true;

console.log('ID is '+empId);

const colorRed=0;
const colorBlue=1;
const colorGreen=2;
enum Color {Red=0,Green=1,Blue=2};

let backgroundColor=Color.Red;

console.log(backgroundColor);