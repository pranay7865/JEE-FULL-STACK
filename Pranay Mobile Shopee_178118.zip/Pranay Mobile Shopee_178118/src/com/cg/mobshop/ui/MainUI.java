package com.cg.mobshop.ui;

import java.util.ArrayList;
import java.util.Collections;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import com.cg.mobshop.dto.Mobiles;
import com.cg.mobshop.exception.MobileException;
import com.cg.mobshop.service.MobileService;
import com.cg.mobshop.service.MobileServiceImpl;
import com.cg.mobshop.util.Util;


public class MainUI 
{

	public static void main(String[] args) throws MobileException 
	{

		Scanner scanner=new Scanner(System.in);
		MobileService service = new MobileServiceImpl();
		Mobiles m=new Mobiles();
		boolean idFlag=false;
		char key;

		while(true) {
			System.out.println("*******Welcome to Pranay Mobile Shopee*******");
			//List<Mobiles> list = new ArrayList<Mobiles>();
			Map<Integer,Mobiles> pmap=service.getMobileList();
			for(Mobiles t:pmap.values()) {
				System.out.println(t);
			}
			//System.out.println("1. Display all");
			System.out.println("1. Sorting Records");
			System.out.println("2. Delete Record");
			System.out.println("3. Exit");
			System.out.println("Enter your Choice : ");
			scanner=new Scanner(System.in);	
			key=scanner.next().charAt(0);

			//int mobileId=0;


			int mobcode = 0;
			switch (key) {


			case '1':
				System.out.print("Sort By :\n1.ID\n2.Name\n3.Price\n ");
				char sortKey=scanner.next().charAt(0);
				List<Mobiles> list=new ArrayList<Mobiles>();
				Map<Integer,Mobiles> map;
				switch (sortKey) {
				case '1':
					map=service.getMobileList();
					for(Mobiles tmp:map.values()) {
						list.add(tmp);
					}
					Collections.sort(list, Mobiles.IdComparator);
					for(Mobiles tmp:list) {
						System.out.println(tmp);
					}


					/*Comparator<Map.Entry<Integer, Product>> com2 = Map.Entry.comparingByValue(Comparator.reverseOrder());

				System.out.println(com2);


				map.entrySet().stream().sorted(comparingByValue).collect(java.util.stream.Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e2) -> e2,HashMap::new));
					 */
					break;

				case '2':	
					map=service.getMobileList();
					for(Mobiles tmp:map.values()) {
						list.add(tmp);
					}
					Collections.sort(list, Mobiles.NameComparator);
					for(Mobiles tmp:list) {
						System.out.println(tmp);
					}
					break;

				case '3':
					map=service.getMobileList();
					for(Mobiles tmp:map.values()) {
						list.add(tmp);
					}
					Collections.sort(list, Mobiles.PriceComparator);
					for(Mobiles tmp:list) {
						System.out.println(tmp);
					}
					break;

				default:
					System.out.println("Invalid choice");
					break;
				}

				break;
			case '2':

				do{
					scanner=new Scanner(System.in);	
					try {
						System.out.println("Enter mobile Id: ");
						mobcode=scanner.nextInt();
						idFlag=true;
					}
					catch(InputMismatchException e) {
						System.err.println("Enter only Number");
					}
				}while(!idFlag);
				m=service.deleteMobile(mobcode);
				if(m!=null) {
					System.out.println("Mobile Id Removed Succesfully."+m);
				}
				else {
					System.out.println("Not Found ");
				}
				break; 

			case '3':
				System.out.println("Thank You!");
				scanner.close();
				System.exit(0);
				break;
			default:
				System.out.println("invalid choice");
				break;
			}

		}

	}

}
