package com.cg.mobshop.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.mobshop.dao.MobileDAO;
import com.cg.mobshop.dao.MobileDAOImpl;

public class MobileDAOImplTest {
	
	MobileDAO dao;
	
	@Before
	public void setUp() throws Exception {
		dao=new MobileDAOImpl();
	}

	@After
	public void tearDown() throws Exception {
		dao=null;
	}

	@Test
	public void testGetMobileList() {
		assertNotNull(dao.getMobileList());
	}

	@Test
	public void testDeleteMobile() {
		assertNotNull(dao.deleteMobile(101));
	}

	@Test
	public void testDeleteMobile1() {
		assertNull(dao.deleteMobile(111));
	}
	
	

}
