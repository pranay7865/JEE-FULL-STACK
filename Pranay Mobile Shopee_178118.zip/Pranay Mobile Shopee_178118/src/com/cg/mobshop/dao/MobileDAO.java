package com.cg.mobshop.dao;

import java.util.List;
import java.util.Map;

import com.cg.mobshop.dto.Mobiles;
import com.cg.mobshop.exception.MobileException;
import com.cg.mobshop.util.Util;

public interface MobileDAO 
{

	public Map<Integer, Mobiles> getMobileList() ;

	public Mobiles deleteMobile(int mobcode) ;

	

}
