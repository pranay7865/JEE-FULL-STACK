package com.cg.mobshop.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cg.mobshop.dto.Mobiles;
import com.cg.mobshop.exception.MobileException;
import com.cg.mobshop.util.Util;

public class MobileDAOImpl implements MobileDAO
{

	Map<Integer, Mobiles> mobileEntries = new HashMap<Integer,Mobiles>();

	@Override
	public Map<Integer, Mobiles> getMobileList()
	{

		return  Util.mobileEntries;
	}


	public Mobiles deleteMobile(int mobcode)
	{
		Mobiles m=null;

		for(Mobiles temp:Util.mobileEntries.values()) {
			
			if(temp.getMobileId()== mobcode) {
				m=temp;
			}
		}
		Util.mobileEntries.remove(m.getMobileId());

		return m;

	}






}
