package com.cg.mobshop.service;

import java.util.List;
import java.util.Map;

import com.cg.mobshop.dao.MobileDAO;
import com.cg.mobshop.dao.MobileDAOImpl;
import com.cg.mobshop.dto.Mobiles;
import com.cg.mobshop.exception.MobileException;
import com.cg.mobshop.util.Util;

public class MobileServiceImpl implements MobileService
{
	MobileDAO dao = new MobileDAOImpl();

	Mobiles m;
	@Override
	public Map<Integer, Mobiles> getMobileList() 
	{
		
		return dao.getMobileList();
	}

	@Override
	public Mobiles deleteMobile(int mobcode) 
	{
		
		return dao.deleteMobile(mobcode);
	}

	
	
	

}
