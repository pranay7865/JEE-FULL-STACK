package com.cg.mobshop.service;

import java.util.List;
import java.util.Map;

import com.cg.mobshop.dto.Mobiles;
import com.cg.mobshop.exception.MobileException;
import com.cg.mobshop.util.Util;

public interface MobileService 
{
	
	public Map<Integer, Mobiles> getMobileList() ;
	
	public Mobiles deleteMobile(int mobileId) ;
	
	
}
