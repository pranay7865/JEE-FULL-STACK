package com.cg.mobshop.dto;

import java.util.Comparator;

public class Mobiles 
{
	private int mobileId;
	private String name;
	private double price;
	private int quantity;
	
	public Mobiles() 
	{
		super();	
	}
	
	public Mobiles(int mobileId, String name, double price, int quantity) 
	{
		super();
		this.mobileId = mobileId;
		this.name = name;
		this.price = price;
		this.quantity = quantity;
	}
	
	public int getMobileId() 
	{
		return mobileId;
	}
	
	public void setMobileId(int mobileId) 
	{
		this.mobileId = mobileId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + mobileId;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		long temp;
		temp = Double.doubleToLongBits(price);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + quantity;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Mobiles other = (Mobiles) obj;
		if (mobileId != other.mobileId)
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (Double.doubleToLongBits(price) != Double.doubleToLongBits(other.price))
			return false;
		if (quantity != other.quantity)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Mobiles [mobileId=" + mobileId + ", name=" + name + ", price=" + price + ", quantity=" + quantity + "]";
	}
	
	public static Comparator<Mobiles> PriceComparator = new Comparator<Mobiles>() {
		public int compare(Mobiles p1, Mobiles p2) {
			double price1=p1.getPrice();
			double price2=p2.getPrice();
			
			return Double.compare(price1, price2);
		} 
		
	};

	public static Comparator<Mobiles> IdComparator = new Comparator<Mobiles>() {
		public int compare(Mobiles p1, Mobiles p2) {
			int id1=p1.getMobileId();
			int id2=p2.getMobileId();
			
			return Integer.compare(id1, id2);
			
		}
	};

	public static Comparator<Mobiles> NameComparator = new Comparator<Mobiles>() {
		public int compare(Mobiles p1, Mobiles p2) {
			String name1=p1.getName();
			String name2=p2.getName();
			
			return name1.compareTo(name2);
		
		} 
		
	};

}
