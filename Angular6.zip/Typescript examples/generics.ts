function GetType<T>(val: T): string{
    return typeof(val);
}

let ename = "Abcd";
let one = 10;
console.log("Call Generics :" + GetType(ename) + " ================ " + GetType(one));



class GetNumber<T>{
    add:(one: T, two: T) => T;
}

var result = new GetNumber<number>();
result.add = function(x, y){
    return x+y;
}

let res = new GetNumber<number>();
console.log(result.add(12,12));
