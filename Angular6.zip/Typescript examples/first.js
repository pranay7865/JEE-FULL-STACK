var id = 12;
console.log("id is: " + id);
function mine() {
    console.log("my function");
}
mine();
