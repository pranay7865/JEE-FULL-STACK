var Employee = {
    firstName: "pavan",
    lastName: "kumar",
    age: 23,
    salary: 43000
};
console.log("dats is: " + Employee.firstName + "--" + Employee.lastName);
console.log("==============================================================");
var employees = [];
employees.push({
    firstName: "pavan",
    lastName: "kumar",
    age: 23,
    salary: 43000
}, {
    firstName: "siva",
    lastName: "krishna",
    age: 33,
    salary: 43000
});
console.log("dats is: " + employees[0].firstName + "--" + employees[0].lastName);
console.log("dats is: " + employees[1].firstName + "--" + employees[1].salary);
console.log("==============================================================");
for (var _i = 0, employees_1 = employees; _i < employees_1.length; _i++) {
    var emp = employees_1[_i];
    console.log(emp.age);
}
