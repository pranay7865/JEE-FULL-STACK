class Animal {
    constructor(public name: string) { 
		console.log("Animal cons...");
		console.log(name);
	}
    move(distanceInMeters: number = 0) {
        console.log(`${this.name} moved ${distanceInMeters}m.`);
    }
}
class Snake extends Animal {
    constructor(name: string) { 
		super(name); 
		console.log("snake cons...");
	}
    move(distanceInMeters = 5) {
        console.log("Slithering...");
		console.log(distanceInMeters);
        super.move(distanceInMeters);
    }
}
class Horse extends Animal {
    constructor(name: string) { 
		super(name); 
		console.log("horse cons...");
	}
    move(distanceInMeters = 45) {
        console.log("Galloping...");
        super.move(distanceInMeters);
    }
}

let snake = new Snake("snkae called");
snake.move();
//snake.move(200);
