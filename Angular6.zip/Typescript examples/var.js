var id = 900;
console.log("id is : " + id);
console.log("============");
var arr = ["a", "b"];
for (var _i = 0, arr_1 = arr; _i < arr_1.length; _i++) {
    var name_1 = arr_1[_i];
    console.log(name_1);
}
console.log("============");
for (var i = 0; i < arr.length; i++) {
    console.log("name is: " + arr[i]);
}
console.log("============");
var salary = 780000;
console.log(salary);
//salary = 90000;
console.log("============");
var colors;
(function (colors) {
    colors[colors["red"] = 0] = "red";
    colors[colors["white"] = 1] = "white";
})(colors || (colors = {}));
var colorname = colors.white;
console.log("name is:" + colorname);
console.log("============");
