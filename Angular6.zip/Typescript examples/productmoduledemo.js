"use strict";
exports.__esModule = true;
var product_1 = require("./product");
//Declare Product
var prod = {
    productId: 1001,
    productName: "iPhone"
};
console.log(prod.productId);
console.log(prod.productName);
var productArray = [
    { productId: 1002, productName: "LG" },
    { productId: 1003, productName: "CoolPad" },
    { productId: 1004, productName: "Mi" }
];
for (var _i = 0, productArray_1 = productArray; _i < productArray_1.length; _i++) {
    var pro = productArray_1[_i];
    console.log(pro.productId);
    console.log(pro.productName);
}
console.log(product_1.company);
