function GetType(val) {
    return typeof (val);
}
var ename = "Abcd";
var one = 10;
console.log("Call Generics :" + GetType(ename) + " ================ " + GetType(one));
var GetNumber = /** @class */ (function () {
    function GetNumber() {
    }
    return GetNumber;
}());
var result = new GetNumber();
result.add = function (x, y) {
    return x + y;
};
var res = new GetNumber();
console.log(res.add(12, 12));
