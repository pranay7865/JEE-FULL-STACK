package com.cg.lms.Util;

import java.util.ArrayList;

import com.cg.lms.Bean.Book;

public class LMSUtil {
	private static ArrayList<Book> list= new ArrayList<>();
	
	static{
		list.add(new Book(101,"Network","R.S. Agrawal"));
		list.add(new Book(102,"Operating System","Galvin"));
	    list.add(new Book(103,"Compiler Design","Rosen"));
	    list.add(new Book(105,"TOC","Will Smith"));
	    list.add(new Book(104,"Artificial Intelligence","Nick Jonas"));
		
		
	
	}
	public static ArrayList<Book> getList() {
		return list;
	}
	public static void setList(ArrayList<Book> list) {
		LMSUtil.list = list;
	}

}
