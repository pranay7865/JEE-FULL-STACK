package dao;

import java.util.ArrayList;
import java.util.Set;

import beans.Book;
import exception.LibraryException;
import util.LibraryUtil;

public class LibraryDao implements ILibraryDao
{
	LibraryUtil u=new LibraryUtil();
	ArrayList<Book> bookEntry = new ArrayList<Book>();
	@Override
	public ArrayList<Book> getAllBooks() throws LibraryException 
	{
		return u.getAllBooks();
	}

	@Override
	public Book searchBookName(String searchBookName) throws LibraryException 
	{
		bookEntry =u.getAllBooks();
		Book bookData = null;
		boolean bookFlag=false;
		
		for(Book book : bookEntry)
		{
			if(book.getBookName().equalsIgnoreCase(searchBookName))
			{
				bookData=book;
				bookFlag=true;
				break;
			}
		}
		
		if(bookFlag==false)
		{
			throw new LibraryException("This Book is not available");
		}
		
		return bookData;
	}

	@Override
	public int addBook(Book book) throws LibraryException {
		/*
		int id=Book.getBookId();
		bookId.getBookId();
		bookEntry = LibraryUtil.getAllBooks();*/
		//Book bookEntry1 = null;
		//boolean flag=false;
		int bookId=book.getBookId();
		bookEntry = u.getAllBooks();
		//Set<Integer> set = new bookEntry.keySet();
		bookEntry.add(book);
		u.setList(bookEntry);
		for(Book b1:bookEntry) {
			System.out.println(b1);
		}
		
		
		return bookId;
	}
	

}
