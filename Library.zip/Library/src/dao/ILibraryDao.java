package dao;

import java.util.ArrayList;

import beans.Book;
import exception.LibraryException;

public interface ILibraryDao {

	ArrayList<Book> getAllBooks() throws LibraryException;

	Book searchBookName(String searchBookName) throws LibraryException;

	int addBook(Book book) throws LibraryException;
	
	
	
	

}
