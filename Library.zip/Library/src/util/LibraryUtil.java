package util;

import java.util.ArrayList;

import beans.Book;

public class LibraryUtil {
	
	public  ArrayList<Book> list = new ArrayList<Book>();
	{
				list.add(new Book(101,"Power of Sub-conscious Mind","Norman Vincent Paule"));
				list.add(new Book(102,"Harry Potter and the Sorcerer's Stone","J. K. Rowling"));
				list.add(new Book(103,"A Game of Thrones","George R. R. Martin"));
				list.add(new Book(104,"Hamlet","William Shakespeare"));
				list.add(new Book(105,"The Fault in Our Stars","John Green"));
	}
		public  ArrayList<Book> getAllBooks()
		{
			return list;
		}
		
		public  void setList(ArrayList<Book> list1)
		{
			list = list1;
		}
}
