package com.cg.pizzaorder.dao.test;

import static org.junit.Assert.*;

import java.util.Date;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.dao.IPizzaOrderDAO;
import com.cg.pizzaorder.dao.PizzaOrderDAO;
import com.cg.pizzaorder.exception.PizzaException;

public class IPizzaOrderDAOTest {
	IPizzaOrderDAO pizzaOrderDAO = null;
	
	@Before
	public void setUp() throws Exception {
		pizzaOrderDAO = new PizzaOrderDAO();
	}

	@After
	public void tearDown() throws Exception {
		pizzaOrderDAO = null;
	}
	
	
	/*@Test
	public void addPizzaOrderNull(){
		PizzaOrder pizzaOrder = new PizzaOrder(1,2,400.0, new Date(), "Mushroom");
		Customer customer = new Customer(1, "abc", "Chennai", "1234567890");
		try {
			Integer orderId = pizzaOrderDAO.placeOrder(customer, pizzaOrder);
			assertNull(orderId);
		} catch (PizzaException e) {
			e.printStackTrace();
		}
	} */
	
	@Test
	public void addPizzaOrder(){

		PizzaOrder pizzaOrder = new PizzaOrder(1,1,400.0, new Date(), "Mushroom");
		Customer customer = new Customer(1, "abc", "Chennai", "1234567890");
		try {
			Integer orderId = pizzaOrderDAO.placeOrder(customer, pizzaOrder);
			assertNotNull(orderId);
		} catch (PizzaException e) {
			e.printStackTrace();
		}
	}
	
	/*@Test
	public void getOrderDetailsNotNull(){
		PizzaOrder pizzaOrder = new PizzaOrder(1,1,400.0, new Date(), "Mushroom");
		Customer customer = new Customer(1, "abc", "Chennai", "1234567890");
		try {
			
			Integer orderId = pizzaOrderDAO.placeOrder(customer, pizzaOrder);
			pizzaOrder = pizzaOrderDAO.getOrderDetails(1);
			assertNotNull(pizzaOrder);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}*/
	
	@Test
	public void getOrderDetails(){
		try {
			PizzaOrder pizzaOrder = pizzaOrderDAO.getOrderDetails(1);
			assertNull(pizzaOrder);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
}
