package com.cg.pizzaorder.bean;

import java.util.Date;

public class PizzaOrder {
	private Integer orderId;
	private Integer customerId;
	private Double totalPrice;
	private Date orderDate;
	private String preferredTopping;
	private Customer customer;

	
	public PizzaOrder() {

	}

	public PizzaOrder(Integer orderId, Integer customerId, Double totalPrice, Date orderDate, String preferredTopping) {
		super();
		this.orderId = orderId;
		this.customerId = customerId;
		this.totalPrice = totalPrice;
		this.orderDate = orderDate;
		this.preferredTopping = preferredTopping;
	}

	public Integer getOrderId() {
		return orderId;
	}

	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}

	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public Double getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(Double totalPrice) {
		this.totalPrice = totalPrice;
	}

	public Date getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}

	public String getPreferredTopping() {
		return preferredTopping;
	}

	public void setPreferredTopping(String preferredTopping) {
		this.preferredTopping = preferredTopping;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	
	
}
