package com.cg.pizzaorder.service;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.dao.IPizzaOrderDAO;
import com.cg.pizzaorder.dao.PizzaOrderDAO;
import com.cg.pizzaorder.exception.PizzaException;

public class PizzaOrderService implements IPizzaOrderService {
	IPizzaOrderDAO pizzaOrderDAO = new PizzaOrderDAO();
	/**
	 * This placeOrder(Customer customer, PizzaOrder pizza) method places the customer order.
	 * Returns order id.
	 */
	@Override
	public int placeOrder(Customer customer, PizzaOrder pizza) throws PizzaException {
		
		int orderPlaced = 0;
		try {
			orderPlaced = pizzaOrderDAO.placeOrder(customer, pizza);
		} catch (PizzaException e) {
			System.out.println("Exception occured while placing pizza order:" + e.getMessage());
			throw new PizzaException(e.getMessage());
		} catch (Exception e) {
			
		}
		return orderPlaced;
	}
	
	/**
	 * This getOrderDetails(int orderId) method gets the order details which has been placed by customer.
	 * Returns PizzaOrder object.
	 */
	@Override
	public PizzaOrder getOrderDetails(int orderId) throws PizzaException {
		PizzaOrder pizzaOrder = null;
		
		try {
			pizzaOrder = pizzaOrderDAO.getOrderDetails(orderId);
		} catch (Exception e) {
			throw new PizzaException("Exception while getting order details:"+e.getMessage());
		}
		return pizzaOrder;
	}

}
