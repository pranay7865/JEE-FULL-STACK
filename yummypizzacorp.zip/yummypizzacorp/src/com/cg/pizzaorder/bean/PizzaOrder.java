package com.cg.pizzaorder.bean;

import java.util.Date;

public class PizzaOrder {
	private int orderId;
	private int customerId;
	private double totalPrice;
	private Date orderDate;
	private String preferredTopping;
	
	private Customer customer;
	

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public double getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}

	public Date getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(java.util.Date date) {
		this.orderDate = date;
	}

	public String getPreferredTopping() {
		return preferredTopping;
	}

	public void setPreferredTopping(String preferredTopping) {
		this.preferredTopping = preferredTopping;
	}

}
