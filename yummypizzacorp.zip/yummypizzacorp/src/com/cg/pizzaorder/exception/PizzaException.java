package com.cg.pizzaorder.exception;

public class PizzaException extends Exception{
	/**
	 * Default serialVersionUID
	 */
	private static final long serialVersionUID = 1L;
	String s1;
	public PizzaException(String s2) {
	      s1 = s2;
	   } 
	   @Override
	   public String toString() { 
	      return ("PizzaException = "+s1);
	   }
	@Override
	public String getMessage() {
		return super.getMessage();
	}
	   
	   
}
