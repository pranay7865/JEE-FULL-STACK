package com.cg.pizzaorder.mainclass;

import java.util.Date;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.service.IPizzaOrderService;
import com.cg.pizzaorder.service.PizzaOrderService;

/**
 * Below is the main class consist of main() method which will execute the pizza order flow. 
 *
 */
public class PizzaOrderMainClass {

	public static void main(String[] args) {
		// Code to display menu to customer
		Scanner sc = null;
		int i=0;
			while(i<10){
			IPizzaOrderService pizzaOrderService = new PizzaOrderService();
			System.out.println("Please select any of the following option:");
			System.out.println("1) Place Order");
			System.out.println("2) Display Order");
			System.out.println("3) Exit");
			try {
				sc = new Scanner(System.in);
				String input = sc.nextLine(); // input will contain the number entered by user
				switch (input) {
				case "1": // Place order
					Customer customer = getCustomerDetails(sc); // gets the customer details from customer
					PizzaOrder pizza = getPizzaOrder(customer.getCustomerId(), sc); // gets the pizza details from customer
					int orderPlaced = pizzaOrderService.placeOrder(customer, pizza);
					if (orderPlaced==1) {
						System.out.println("Pizza Order successfully placed with Order Id:" + pizza.getOrderId());
					} else{
						System.out.println("Pizza order failed.");
					}
					break;
				case "2": // Display order
					System.out.println("Please enter your order id:");
					
					String orderId = sc.nextLine();
					int inputVal = Integer.parseInt(orderId);
					PizzaOrder pizza1 = pizzaOrderService.getOrderDetails(inputVal);
					if (null != pizza1) {
						System.out.println("Your order details are:");
						System.out.println("Order id:" + pizza1.getOrderId() + " Preferred Toppings:" + pizza1.getPreferredTopping() + " Price:" + pizza1.getTotalPrice());
						System.out.println("Customer Id :" +pizza1.getCustomer().getCustomerId()+" Customer Name : "+pizza1.getCustomer().getCustName()+" Customer Address : "+pizza1.getCustomer().getAddress()+" Customer Phone No. : "+pizza1.getCustomer().getPhone());
					} else {
						System.out.println("Invalid order id entered!");
					}
					break;
				case "3":
					System.exit(0);
					
				default:
						System.out.println("Do you wish to continue(Y/N):");
						String continueFlag = sc.nextLine();
						if (continueFlag.trim().toLowerCase().equals("y")) {
							main(args);
						} else{
							System.exit(0);
						}
						//break;
				}
				
			} catch (Exception e) {
				System.out.println("Exception occured while reading line from console:-" +e.getMessage());
			} 
			i++;
		}
	}
	/**
	 * This getPizzaOrder(int custId, Scanner sc) method will display the toppings option to user and returns the PizzaOrder object
	 * @param custId int
	 * @param sc Scanner
	 * @return PizzaOrder
	 */
	private static PizzaOrder getPizzaOrder(int custId, Scanner sc) {
		PizzaOrder pizzaOrder = new PizzaOrder();
		int basePrice = 350;
		int totalPrice = 0;
		try {
			System.out.println("Pizza toppings		Price (in Rs)");
			System.out.println("Capsicum			30");
			System.out.println("Mushroom			50");
			System.out.println("Jalapeno			70");
			System.out.println("Paneer			        85");
			System.out.println("Type of Pizza Topping preferred:");
			
			String toppings = sc.nextLine();
			switch (toppings.trim().toLowerCase()) {
			case "capsicum":
							totalPrice = basePrice + 30;
							break;
			case "mushroom":
							totalPrice = basePrice + 50;
							break;
			case "jalapeno":
							totalPrice = basePrice + 70;
							break;
			case "paneer":
							totalPrice = basePrice + 85;
							break;
			}
			int orderId = (int)(Math.random() * 10); // generate random number in integer format because Math.random() generates double value.
			
			pizzaOrder.setOrderId(orderId);
			pizzaOrder.setCustomerId(custId);
			pizzaOrder.setTotalPrice(totalPrice);
			pizzaOrder.setOrderDate(new Date());
			pizzaOrder.setPreferredTopping(toppings.trim());
		} catch (Exception e) {
			System.out.println("Exception occured while pizza order:" + e.getMessage());
		} 
		
		return pizzaOrder;
	}
	/**
	 * This getCustomerDetails(Scanner sc) method will accept the customer details and add them in customer object and return it.
	 * @param sc Scanner
	 * @return Customer
	 */
	private static Customer getCustomerDetails(Scanner sc) {
		Customer customer = new Customer();
		try {
			System.out.println("Enter the name of customer:");
			String custName = sc.nextLine();
			System.out.println("Enter customer address:");
			String custAddr = sc.nextLine();
			System.out.println("Enter customer phone number:");
			String custPhone = sc.nextLine();
			boolean validPhone = validateCustPhone(custPhone);
			if (!validPhone) {
				System.out.println("You have entered invalid mobile number. Try again!");
				PizzaOrderMainClass.main(null);
			}
			int custId = (int)(Math.random() * 10); // generate random number in integer format because Math.random() generates double value.
			customer.setCustomerId(custId);
			customer.setCustName(custName);
			customer.setAddress(custAddr);
			customer.setPhone(custPhone);
			
		} catch (Exception e) {
			System.out.println("Exception occured while getting customer details: " + e.getMessage());
		} 
		return customer;
	}
	/**
	 * This validateCustPhone(String custPhone) method will validate the mobile number is of 10 digits or not
	 * @param custPhone String
	 * @return boolean
	 */
	private static boolean validateCustPhone(String custPhone) {
		Pattern p = Pattern.compile("[0-9]{10}"); // This pattern object will make sure only 10 digit numeric value should be entered.
		  
        // Pattern class contains matcher() method 
        // to find matching between given number  
        // and regular expression 
        Matcher m = p.matcher(custPhone); 
        return (m.find() && m.group().equals(custPhone));
		
	}

}
