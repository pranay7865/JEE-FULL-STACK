package com.cg.pizzaorder.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.exception.PizzaException;

public class PizzaOrderDAO implements IPizzaOrderDAO {
	//map for orderid as key and pizza order as value
	static Map<Integer, PizzaOrder> pizzaEntry = new HashMap<Integer, PizzaOrder>();
	//map for customerid as key and customer object as value
	static Map<Integer, Customer> customerEntry = new HashMap<Integer, Customer>();
	
	@Override
	public int placeOrder(Customer customer, PizzaOrder pizza) throws PizzaException {
		int orderPlaced = 0;
		try {
			// adding pizza order details to pizzaEntry map
			pizzaEntry.put(pizza.getOrderId(), pizza);
			// adding customer details to customerEntry map
			customerEntry.put(pizza.getOrderId(), customer);
			orderPlaced = 1;
		} catch (Exception e) {
			throw new PizzaException("Exception while adding order to map:" + e.getMessage());
		}
		return orderPlaced;
	}

	@Override
	public PizzaOrder getOrderDetails(int orderId) throws PizzaException {
		PizzaOrder pizzaOrder = null;
		if (pizzaEntry.size() > 0) {
			for (Map.Entry<Integer, PizzaOrder> pizzaOrd : pizzaEntry.entrySet()) {
				if (null != pizzaOrd && Integer.valueOf(orderId)==pizzaOrd.getKey()) {
					pizzaOrder = new PizzaOrder();
					pizzaOrder = pizzaOrd.getValue();
				}
			}
		}
		
		
		if (customerEntry.size() > 0) {
			for (Map.Entry<Integer, Customer> customerEn : customerEntry.entrySet()) {
				if (null != customerEn  && Integer.valueOf(orderId)==customerEn.getKey()) {
					if(null!=pizzaOrder)
					{
						Customer cust=new Customer();
						cust=customerEn.getValue();
						pizzaOrder.setCustomer(cust);
					}
				}
			}
		}
		
		
		return pizzaOrder;
	}

}
