package com.cg.mo.Service;

import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import com.cg.mo.DAO.DAOImpl;
import com.cg.mo.DAO.DAOInterface;
import com.cg.mo.Exception.MobileException;
import com.cg.mo.bean.Mobile;

public class ServiceImpl implements ServiceInterface {
	DAOInterface dao= new DAOImpl();

	@Override
	public void purchasePhone() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int displayOrderDetails() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Map phoneStock() {
		// TODO Auto-generated method stub
		return dao.phoneStock();
	}

	@Override
	public void validateCustName(String custName) throws MobileException {
		  String regEx1="[A-Z ]{1}[a-z]{3,9}";
			if(!Pattern.matches(regEx1,custName)){
				throw new MobileException("Enter alphabets only");
	}

}

	@Override
	public void validateCustAddress(String custAddress) throws MobileException {
		String regEx1="[A-Z ]{1}[a-z]{3,9}";
		if(!Pattern.matches(regEx1,custAddress)){
			throw new MobileException("Enter alphabets only");
}
		
	}

	public void validateCustPhone(String custPhone) throws MobileException {
		String regEx1="[9|8]{1}[0-9]{9}";
		if(!Pattern.matches(regEx1,custPhone)){
			throw new MobileException("Enter alphabets only");
}

		
	}

	@Override
	public Mobile orderPhone(String modelName) throws MobileException {
		return dao.orderPhone(modelName);
		
	}

	
	}
