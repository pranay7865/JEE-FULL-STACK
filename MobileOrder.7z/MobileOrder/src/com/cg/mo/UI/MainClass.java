package com.cg.mo.UI;

import java.time.LocalDate;
import java.util.InputMismatchException;
import java.util.Scanner;

import com.cg.mo.Exception.MobileException;
import com.cg.mo.Service.ServiceImpl;
import com.cg.mo.Service.ServiceInterface;
import com.cg.mo.Util.UtilClass;
import com.cg.mo.bean.Customer;
import com.cg.mo.bean.Mobile;

public class MainClass {
	public static void main(String args[]){
		Scanner scan= null;
		Mobile mob= new Mobile();
		ServiceInterface service= new ServiceImpl();
		//UtilClass util= new UtilClass();
		String continueChoice="";
		do{
			System.out.println("--Mobile Shop--");
			System.out.println("1.Available Phones\n2.Purchase Phone\n3 Order Details\n4.Exit");
			int choice=0;
			boolean choiceFlag=false;
		do{
			scan= new Scanner(System.in);
			System.out.println("enter your choice");
			try {
					choice=scan.nextInt();
					choiceFlag=true;
					switch(choice){
			
					case 1:
						System.out.println("The Phones in our store:");
						service.phoneStock();
						break;
						
					case 2:
						String custName="";
						boolean custNameFlag=false;
						do
						{
							System.out.println("enter your Name");
							scan= new Scanner(System.in);
							try {
								custName= scan.next();
								service.validateCustName(custName);
								//stud.setStudentName(studentName);
								custNameFlag=true;
								break;
					         }
							catch(MobileException e)
							{
								custNameFlag=false;
								System.err.println(e.getMessage());
							}
						}while(!custNameFlag);
						String custAddress="";
						boolean custAddressFlag=false;
						do
						{
							System.out.println("enter your address");
							scan= new Scanner(System.in);
							try {
								custAddress= scan.next();
								service.validateCustAddress(custAddress);
								//stud.setStudentName(studentName);
								custAddressFlag=true;
								break;
					         }
							catch(MobileException e)
							{
								custAddressFlag=false;
								System.err.println(e.getMessage());
							}
						}while(!custAddressFlag);
						String custPhone="";
						boolean custPhoneFlag=false;
						do
						{
							System.out.println("enter your phone number");
							scan= new Scanner(System.in);
							try {
								custPhone= scan.next();
								service.validateCustPhone(custPhone);
								//stud.setStudentName(studentName);
								custPhoneFlag=true;
								break;
					         }
							catch(MobileException e)
							{
								custPhoneFlag=false;
								System.err.println(e.getMessage());
							}
						}while(!custAddressFlag);
						String modelName="";
						boolean modelFlag=false;
						do{
							scan= new Scanner(System.in);
							System.out.println("enter Model name");
					
								modelName= scan.next();
							    modelFlag=true;
							    Mobile mobile;
							    LocalDate date= LocalDate.now();
							    try{
				mobile=service.orderPhone(modelName);
				int orderId= (int) (Math.random()*10000);
				mobile.setOrderId(orderId);
				
				System.out.println("order placed with  " +orderId);
							    	System.out.println(mobile);
							    	}
							    	catch(MobileException e1){
							    		System.err.println(e1.getMessage());
							    	}
							    }
						while(!modelFlag);
								break;
	
	
						
					case 3:
						int orderId=0;
						boolean orderIdFlag=false;
						do
						{
							System.out.println("enter your Order id");
							scan= new Scanner(System.in);
							try {
								orderId= scan.nextInt();
								Mobile mobile1;
					Mobile mb=service.getOrderDetails(orderId);
						Customer cust= new Customer();
						
			//stud.setStudentName(studentName);
								orderIdFlag=true;
								break;
					         }
							catch(MobileException e)
							{
								orderIdFlag=false;
								System.err.println(e.getMessage());
							}
						}while(!orderIdFlag);
		
		
			
			
			
			
					}
			}catch(InputMismatchException e) {
				System.err.println("enter digits only");
		
			}
			}
		while(!choiceFlag);
			
			scan= new Scanner(System.in);
		System.out.println("do u want to continue again(yes/no)");
		continueChoice = scan.next();
	} while (continueChoice.equalsIgnoreCase("yes"));
	//scan.close();
		
		
		
	}
}