package com.cg.mo.DAO;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;


import com.cg.mo.Exception.MobileException;
import com.cg.mo.Util.UtilClass;
import com.cg.mo.bean.Customer;
import com.cg.mo.bean.Mobile;

public class DAOImpl implements DAOInterface {
	UtilClass uc= new UtilClass();
	Customer c= new Customer();
	@Override
	public void purchasePhone() {
		// TODO Auto-generated method stub
		
	}
	public Map phoneStock() {
		Map<Integer,Mobile>hm=uc.getMap1();
		for(Mobile o:hm.values()) {
			System.out.println(o);
		}
		return uc.getMap1();
	}
	@Override
	public Mobile orderPhone(String modelName) throws MobileException {
	Map<Integer, Mobile> map= uc.getMap1();
	ArrayList<Mobile> mobile= new ArrayList<>();
	Mobile m=null;
		boolean flag=false;
		for(Mobile mob:map.values()){
		if(mob.getModelNo().equalsIgnoreCase(modelName))
		{
			m=mob;
			flag=true;
			break;
		}
		}
	if(flag==false)
	{
		throw new MobileException("This Phone is not available");
		}
	
		
	
		return m;

	}




	@Override
	public Mobile displayOrderDetails(int orderId) throws MobileException {
		Map<Integer, Mobile> map= uc.getMap1();
		ArrayList<Mobile> mobile= new ArrayList<>();
		Mobile m=null;
			boolean flag=false;
			for(Mobile mob:map.values()){
			if(mob.getOrderId()==orderId)
			{
				m=mob;
				flag=true;
				break;
			}
			}
		if(flag==false)
		{
			throw new MobileException("Order id mismatched");
			}
		
			
		System.out.println(m);
			return m;

		}
		
	}

	
	

	