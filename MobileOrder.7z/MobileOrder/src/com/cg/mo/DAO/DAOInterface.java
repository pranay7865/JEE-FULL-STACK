package com.cg.mo.DAO;

import java.util.List;
import java.util.Map;

import com.cg.mo.Exception.MobileException;
import com.cg.mo.bean.Customer;
import com.cg.mo.bean.Mobile;

public interface DAOInterface {
	public void purchasePhone();
	public int displayOrderDetails();
	public  Map phoneStock();
	public Mobile orderPhone(String modelName) throws MobileException;
	

	

}
