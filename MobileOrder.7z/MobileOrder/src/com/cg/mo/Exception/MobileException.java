package com.cg.mo.Exception;

public class MobileException extends Exception {

	public MobileException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	
}


	
	
