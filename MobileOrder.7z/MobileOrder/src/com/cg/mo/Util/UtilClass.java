package com.cg.mo.Util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cg.mo.bean.Customer;
import com.cg.mo.bean.Mobile;

public class UtilClass {
	
	
	public static Map<Integer,Mobile> map1= new HashMap<>();
	static{
		map1.put(1, new Mobile(1,"Samsung",25000d));
		map1.put(2, new Mobile(2,"Nokia",11000d));
		map1.put(3, new Mobile(3,"Moto",19000d));
		map1.put(4, new Mobile(4,"Apple",20000d));
		map1.put(5, new Mobile(5,"Lava",25000d));
		
		
	}
	public static Map<Integer, Mobile> getMap1() {
		return map1;
	}
	public static void setMap1(Map<Integer, Mobile> map1) {
		UtilClass.map1 = map1;
	}
	
	
}

