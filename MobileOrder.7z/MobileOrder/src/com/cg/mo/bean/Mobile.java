package com.cg.mo.bean;

public class Mobile {
	private int orderId;
	public Mobile(int orderId, String modelNo, double totalPricewithGST) {
		super();
		this.orderId = orderId;
		this.modelNo = modelNo;
		this.totalPricewithGST = totalPricewithGST;
	
	}
	public Mobile() {
		// TODO Auto-generated constructor stub
	}
	private int customerId;
	private String modelNo;
	public String getModelNo() {
		return modelNo;
	}
	public void setModelNo(String modelNo) {
		this.modelNo = modelNo;
	}
	private double totalPricewithGST;

	
	
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public double getTotalPricewithGST() {
		return totalPricewithGST;
	}
	public void setTotalPricewithGST(double totalPricewithGST) {
		this.totalPricewithGST = totalPricewithGST;
	}
	@Override
	public String toString() {
		return " ModelNo=" + modelNo
				+ "\n TotalPricewithGST=" + totalPricewithGST;
	}
	
}
