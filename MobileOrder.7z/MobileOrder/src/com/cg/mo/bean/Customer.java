package com.cg.mo.bean;

public class Customer {
	// Entities in the bean class
	private int customerId;
	private String custName;
	private String custAddress;
	private String custPhone;
	// Constructor using fields
	public Customer(int customerId, String string, String string2,
			String custPhone) {
		super();
		this.customerId = customerId;
		this.custName = string;
		this.custAddress = string2;
		this.custPhone = custPhone;
	}

	
	
	


	public Customer() {
		// TODO Auto-generated constructor stub
	}






	public int getCustomerId() {
		return customerId;
	}



	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}



	public String getCustName() {
		return custName;
	}



	public void setCustName(String custName) {
		this.custName = custName;
	}



	public String getCustAddress() {
		return custAddress;
	}



	public void setCustAddress(String custAddress) {
		this.custAddress = custAddress;
	}



	public String getCustPhone() {
		return custPhone;
	}
	public void setCustPhone(String custPhone) {
		this.custPhone = custPhone;
	}
	//generating String to String to override the method

	public String toString() {
		return "Customer [customerId=" + customerId + ", custName=" + custName
				+ ", custAddress=" + custAddress + ", custPhone=" + custPhone
				+ "]";
	}
	
}
