package com.cg.cms.bean;

public class Cab 
{
	private String name;
	private String mobile;
	private String pickUp;
	private String drop;
	
	public Cab() {
		super();
		
	}

	public Cab(String name, String mobile, String pickUp, String drop) {
		super();
		this.name = name;
		this.mobile = mobile;
		this.pickUp = pickUp;
		this.drop = drop;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getPickUp() {
		return pickUp;
	}

	public void setPickUp(String pickUp) {
		this.pickUp = pickUp;
	}

	public String getDrop() {
		return drop;
	}

	public void setDrop(String drop) {
		this.drop = drop;
	}

	@Override
	public String toString() {
		return "Cab [name=" + name + ", mobile=" + mobile + ", pickUp=" + pickUp + ", drop=" + drop + "]";
	}

	
	
	
	

}
