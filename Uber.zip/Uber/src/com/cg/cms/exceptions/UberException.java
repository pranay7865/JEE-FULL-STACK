package com.cg.cms.exceptions;

public class UberException extends Exception
{

	public UberException(String message) {
		super(message);
		
	}
	

}
