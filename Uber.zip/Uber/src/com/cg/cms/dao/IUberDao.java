package com.cg.cms.dao;

import com.cg.cms.bean.Cab;
import com.cg.cms.exceptions.UberException;

public interface IUberDao 
{
	public Cab getUberBook(Cab cab) throws UberException;
	
	public Cab getUberDetails() throws UberException;

}
