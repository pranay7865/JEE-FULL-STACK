package com.cg.cms.dao;

import java.util.ArrayList;

import com.cg.cms.bean.Cab;
import com.cg.cms.exceptions.UberException;

public class UberDao implements IUberDao
{

	ArrayList<Cab> list = new ArrayList<Cab>();
	
	
	@Override
	public Cab getUberBook(Cab cab) throws UberException 
	{
		
		return cab;
	}

	@Override
	public Cab getUberDetails() throws UberException 
	{
		Cab cab = null;
		return cab;
		
	}

}
