package com.cg.pms.ui;

import java.util.Collections;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.cg.pms.bean.Product;
import com.cg.pms.service.IService;
import com.cg.pms.service.Service;

public class User {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			
		Scanner scanner;
		IService service=new Service();
		int prodId=0;
		Product p=null;
		boolean idFlag=false;
		char key;
		
		while(true) {
				
				System.out.println("1. Display all");
				System.out.println("2. Search");
				System.out.println("3. Delete");
				System.out.println("4. Sort");
				System.out.println("5. Exit");
				System.out.println("choose: ");
			scanner=new Scanner(System.in);	
			key=scanner.next().charAt(0);
			
			switch (key) {
			
			case '1':
				List<Product> plist=service.displayAll();
				for(Product tmp:plist) {
					System.out.println(tmp);
				}
				
				break;
			case '2':
				int id=0;
				do{
					scanner=new Scanner(System.in);	
					try {
					System.out.println("Enter Product Id: ");
					
					id=scanner.nextInt();
					idFlag=true;
					
					}
					catch(InputMismatchException e) {
							System.err.println("Enter only Number");
					}
					p=service.searchProduct(id);
					if(p!=null) 
						System.out.println(p);
					
				}while(!idFlag);
				
				
				break;
					
			case '3':

				do{
					scanner=new Scanner(System.in);	
					try {
					System.out.println("Enter Product Id: ");
					prodId=scanner.nextInt();
					idFlag=true;
					}
					catch(InputMismatchException e) {
							System.err.println("Enter only Number");
					}
				}while(!idFlag);
				p=service.removeProduct(prodId);
				if(p!=null) {
					System.out.println("Removed Succesfully."+p);
				}
				else {
					System.out.println("Not Found ");
				}
				break; 
			case '4':
				System.out.print("1.ID 2.Name 3.Price\nSort By : ");
				char sortKey=scanner.next().charAt(0);
				List<Product> list;
				switch (sortKey) {
				case '1':
					list=service.displayAll();
					Collections.sort(list, Product.IdComparator);
					for(Product tmp:list) {
						System.out.println(tmp);
					}
					break;

				case '2':
					list=service.displayAll();
					Collections.sort(list, Product.NameComparator);
					for(Product tmp:list) {
						System.out.println(tmp);
					}
					break;
					
				case '3':
					list=service.displayAll();
					Collections.sort(list, Product.PriceComparator);
					for(Product tmp:list) {
						System.out.println(tmp);
					}
					break;
				default:
					System.out.println("invalid choice");
					break;
				}
					
				break;
			case '5':
				System.out.println("Thank You!");
				scanner.close();
				System.exit(0);
				break;
			default:
				System.out.println("invalid choice");
				break;
			}
			
		}
		
		
	}

}
