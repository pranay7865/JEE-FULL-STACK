package com.cg.pms.util;

import java.util.*;
import com.cg.pms.bean.Product;

public class Products {

	public static List<Product> productList=new ArrayList<Product>();
	static {
		productList.add(new Product(1,"tv",20000d));
		productList.add(new Product(2,"radio",1000d));
		productList.add(new Product(3,"fridge",22000d));
		productList.add(new Product(4,"ac",40000d));
		productList.add(new Product(5,"cooler",8000d));
		productList.add(new Product(6,"laptop",75000d));
		productList.add(new Product(7,"chair",200d));
	}
	public Products() {
		super();
		// TODO Auto-generated constructor stub
	}
	public static List<Product> getProductList() {
		return productList;
	}
	
	public static void setProductList(List<Product> productList) {
		Products.productList = productList;
	}
		
	
}
