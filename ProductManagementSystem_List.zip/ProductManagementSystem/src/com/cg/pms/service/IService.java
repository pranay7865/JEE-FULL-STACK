package com.cg.pms.service;

import java.util.List;

import com.cg.pms.bean.Product;

public interface IService {

	public List<Product> displayAll();

	public Product searchProduct(int prodId);

	public Product removeProduct(int prodId);
}
