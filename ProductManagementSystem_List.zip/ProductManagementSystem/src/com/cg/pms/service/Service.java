package com.cg.pms.service;

import java.util.List;

import com.cg.pms.bean.Product;
import com.cg.pms.dao.DAO;
import com.cg.pms.dao.IDAO;

public class Service implements IService {

	IDAO dao=new DAO();
	
	@Override
	public List<Product> displayAll() {

		
		return dao.displayAll();
	}

	@Override
	public Product searchProduct(int prodId) {
		// TODO Auto-generated method stub
		return dao.searchProduct(prodId);
	}

	@Override
	public Product removeProduct(int prodId) {
		// TODO Auto-generated method stub
		return dao.removeProduct(prodId);
	}

}
