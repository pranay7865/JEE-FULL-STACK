package com.cg.pms.dao;

import java.util.List;

import com.cg.pms.bean.Product;
import com.cg.pms.util.Products;

public class DAO implements IDAO {

	@Override
	public List<Product> displayAll() {

		return Products.productList;
	}

	@Override
	public Product searchProduct(int prodId) {

		Product p=null;;
		for(Product temp:Products.productList) {
			if(temp.getId()==prodId)
				p=temp;
		}
		return p;
	}

	@Override
	public Product removeProduct(int prodId) {
		
		Product p=null;
		
		for(Product temp:Products.productList) {
			if(temp.getId()==prodId) {
				p=temp;
			}
		}
		Products.productList.remove(p);
		
		return p;
	}

}
