package com.cg.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
	public static Connection conn;
	private static final long serialVersionUID = 1L;

	public RegisterServlet() {
		super();

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		

		response.setContentType("text/html");// MIME type
		PrintWriter out = response.getWriter();

		String fname = request.getParameter("fn");
		String lname = request.getParameter("ln");
		String email = request.getParameter("em");
		String mob = request.getParameter("mb");
		String add = request.getParameter("add");

		/*
		 * out.println("<h2>Welcome to Employee Registration</h2>");
		 * out.println("Wooho! Mr. <strong>"
		 * +lname+"</strong> you have successfully registered!");
		 * out.println("<h3>Your Details :</h3> ");
		 * out.println("<h4>First Name : "+fname+"</h4>");
		 * out.println("<h4>Last Name : "+lname+"</h4>");
		 * out.println("<h4>Email : "+email+"</h4>");
		 * out.println("<h4>Mobile No. : "+mob+"</h4>");
		 * out.println("<h4>Address : "+add+"</h4>");
		 */

		try {
			// Thread.sleep(10000);
			Class.forName("oracle.jdbc.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "System", "India123");
			PreparedStatement ps = conn.prepareStatement(
					"Insert into employee1 values(?,?,?,?,?,seq1.nextval)");
			//ps.setInt(1, Integer.parseInt(id));
			ps.setString(1, fname);
			ps.setString(2, lname);
			ps.setString(3, email);
			ps.setInt(4, Integer.parseInt(mob));
			ps.setString(5, add);
			int i = ps.executeUpdate();
			if (i > 0) {
				out.println("<h2>Welcome to Employee Registration</h2>");
				out.println("Wooho! Mr. <strong>" + lname + "</strong> you have successfully registered!");
				out.println("<h3>Your Details :</h3> ");
				out.println("<h4>First Name : " + fname + "</h4>");
				out.println("<h4>Last Name : " + lname + "</h4>");
				out.println("<h4>Email : " + email + "</h4>");
				out.println("<h4>Mobile No. : " + mob + "</h4>");
				out.println("<h4>Address : " + add + "</h4>");
			} else {
				out.println("<h3 font-color=red>Entry not registered </h3>");

			}

			System.out.println("Connection setup ok");
		} catch (SQLException e) {
			// System.out.println("Problem Occured");
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// System.out.println("Driver Load problem");
			e.printStackTrace();
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				//e1.printStackTrace();
				System.out.println("Connection was not closed properly!");
			}
		}
		//System.out.println("Take a break!!!");
	}

}


/*create trigger trg before insert on employee1 for each row begin
2  :new.id:=seq1.nextval;
3  end;
4  /*/