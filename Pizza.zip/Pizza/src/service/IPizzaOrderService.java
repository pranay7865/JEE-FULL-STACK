package service;

import bean.Customer;
import bean.PizzaOrder;
import exception.PizzaException;

public interface IPizzaOrderService 
{
	
	public int placeOrder(Customer customer,PizzaOrder pizza) throws PizzaException;
	
	public PizzaOrder getOrderDetails(int orderid) throws PizzaException;
	
	public void validateName(String custName) throws PizzaException;
	
	public void validateAddress(String address) throws PizzaException;
	
	public void validatePhone(String phone) throws PizzaException;
	
	public void validateTopping(String topping) throws PizzaException;
	
	public void validateOrderId(int orderId) throws PizzaException;
	


}
