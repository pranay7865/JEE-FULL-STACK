package service;

import java.util.regex.Pattern;

import bean.Customer;
import bean.PizzaOrder;
import dao.IPizzaOrderDAO;
import dao.PizzaOrderDAO;
import exception.PizzaException;

public class PizzaOrderService implements IPizzaOrderService
{
	IPizzaOrderDAO pizzadao =new PizzaOrderDAO();

	@Override
	public int placeOrder(Customer customer, PizzaOrder pizza) throws PizzaException {
		
		return pizzadao.placeOrder(customer, pizza);
	}

	@Override
	public PizzaOrder getOrderDetails(int orderid) throws PizzaException {
		
		return pizzadao.getOrderDetails(orderid);
	}

	@Override
	public void validateName(String custName) throws PizzaException {
		String nameRegEx = "[a-zA-Z ]+";
		if(Pattern.matches(nameRegEx, custName)== false)
		{
			throw new PizzaException("Name should contain alphabets only.");
		}
	}

	@Override
	public void validateAddress(String address) throws PizzaException {
		String addressRegEx = "[a-zA-Z ]+";
		if(Pattern.matches(addressRegEx, address)== false)
		{
			throw new PizzaException("Address should contain alphabets only.");
		}
	}

	@Override
	public void validatePhone(String phone) throws PizzaException {
		String phoneRegEx = "[7|8|9]{1}[0-9]{9}";
		if(Pattern.matches(phoneRegEx, phone)== false)
		{
			throw new PizzaException("Phone number should consists of 10 digits only.");
		}
		
	}

	@Override
	public void validateTopping(String topping) throws PizzaException {
		String toppingRegEx = "[a-zA-Z ]+";
		if(Pattern.matches(toppingRegEx, topping)== false)
		{
			throw new PizzaException("Topping name should contain alphabets only.");
		}
		
	}

	@Override
	public void validateOrderId(int orderId) throws PizzaException {
		String orderIdRegEx="[0-9 ]+";
		if(Pattern.matches(orderIdRegEx, String.valueOf(orderId)) == false)
			throw  new PizzaException("Order Id should contain digits only.");
		
	}
	
	
	
	

}
