package ui;

import java.time.LocalDate;
import java.util.InputMismatchException;
import java.util.Locale;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;
import java.util.regex.Pattern;

import bean.Customer;
import bean.PizzaOrder;
import dao.PizzaOrderDAO;
import exception.PizzaException;
import service.IPizzaOrderService;
import service.PizzaOrderService;

public class Client {

	public static void main(String[] args) 
	{
		Customer cust=new Customer();
		Scanner scanner=null;
		IPizzaOrderService pizzaservice =new PizzaOrderService();
		String contiChoice="";
		
		do {
			
			System.out.println("***********Pizza Application***********");
			
			System.out.println("1)\tPlace Order");
			System.out.println("2)\tDisplay Order");
			System.out.println("3)\tExit");
			System.out.println("Toppings\t\t\tPrice (in Rs)");
			System.out.println("Capsicum\t\t\t30");
			System.out.println("Mushroom\t\t\t50");
			System.out.println("Jalapeno\t\t\t70");
			System.out.println("Paneer\t\t\t\t85");
			System.out.println("Please select your choice from options : ");
			
			int choice=0;
			boolean choiceFlag=false;
			
			do {
				scanner = new Scanner(System.in);
				try {
					choice=scanner.nextInt();
					choiceFlag=true;
					
					
					switch(choice)
					{
					case 1:
					{
						String custName="";
						boolean custNameFlag=false;
						do {
							scanner=new Scanner(System.in);
							System.out.println("Enter the name of the customer");
							custName=scanner.nextLine();
							try {
								pizzaservice.validateName(custName);
								cust.setCustName(custName);
								custNameFlag=true;
								break;
								
							} catch (PizzaException e) {
								custNameFlag=false;
								System.err.println(e.getMessage());
							}
						}while(!custNameFlag);
						
						String address="";
						boolean addressFlag=false;
						do {
							scanner=new Scanner(System.in);
							System.out.println("Enter the address of the customer");
							address=scanner.nextLine();
							try {
								pizzaservice.validateAddress(address);
								cust.setAddress(address);
								addressFlag=true;
								break;
								
							} catch (PizzaException e) {
								addressFlag=false;
								System.err.println(e.getMessage());
							}
						}while(!addressFlag);
						
						
						String phone="";
						boolean phoneFlag=false;
						do {
							scanner=new Scanner(System.in);
							System.out.println("Enter the phone number of the customer");
							phone=scanner.nextLine();
							try {
								pizzaservice.validatePhone(phone);
								cust.setPhone(phone);
								phoneFlag=true;
								break;
								
							} catch (PizzaException e) {
								phoneFlag=false;
								System.err.println(e.getMessage());
							}
						}while(!phoneFlag);
						
						String topping="";
						boolean toppingFlag=false;
						do {
							scanner=new Scanner(System.in);
							System.out.println("Enter the Type of Topping you preferred : ");
							topping=scanner.nextLine();
							try {
								pizzaservice.validateTopping(topping);
								toppingFlag=true;
								break;
							} catch (PizzaException e) {
								toppingFlag=false;
								System.err.println(e.getMessage());
							}
						}while(!toppingFlag);
						
						Map<String, Integer> map = new TreeMap<String, Integer>();
						map.put("Capsicum", 30);
						map.put("Mushroom", 50);
						map.put("Jalapeno", 70);
						map.put("Paneer", 85);
						
						int totalPrice=0;
						
						Set<String> set=map.keySet();
						for(String toppingName : set)
						{
							if(toppingName.equalsIgnoreCase(topping))
							{
								totalPrice = map.get(toppingName) + 350;
								break;
							}
						}
						System.out.println("Price : " + totalPrice);
						
						LocalDate localDate =LocalDate.now();
						System.out.println("Order Date : " + localDate);
						
						//Customer customer=new Customer();
						PizzaOrder pizza=new PizzaOrder();
						
						try {
							int orderId=pizzaservice.placeOrder(cust, pizza);
							System.out.println("Your order is placed successfully with order ID : " +orderId);
						} catch (PizzaException e) {
							System.err.println(e.getMessage());
						}
						
						break;
					}	
					case 2:
					{
						int orderId=0;
						boolean orderIdFlag=false;
						PizzaOrder pizzaorder=null;
						do {
							scanner=new Scanner(System.in);
							System.out.println("Enter your order Id : ");
							try {
								 orderId=scanner.nextInt();
								pizzaservice.validateOrderId(orderId);
								pizzaorder=pizzaservice.getOrderDetails(orderId);
								orderIdFlag=true;
							} catch (InputMismatchException e) {
								orderIdFlag=false;
								System.err.println(e.getMessage());
							}
							catch(PizzaException e)
							{
								System.err.println(e.getMessage());
							}
						}while(!orderIdFlag);
						
						try {
							pizzaorder=pizzaservice.getOrderDetails(orderId);
							int customerId=pizzaorder.getCustomerId();
							
							//System.out.println("Customer Id :" +customer1.getCustomer().getCustomerId()+" Customer Name : "+pizza1.getCustomer().getCustName()+" Customer Address : "+pizza1.getCustomer().getAddress()+" Customer Phone No. : "+pizza1.getCustomer().getPhone());
							PizzaOrderDAO d=new PizzaOrderDAO();
							Customer customer1=d.getCustomer(customerId);
							customer1.setCustomerId(customerId);
							//System.out.println(customer1);
							System.out.println("Customer Id : "+customer1.getCustomerId()+", Customer Name : "+customer1.getCustName()+", Customer Address : "+customer1.getAddress()+", Customer Phone No. : "+customer1.getPhone());
							
						} catch (PizzaException e) {
							System.err.println(e.getMessage());
						}
						
						break;
					}	
					case 3:
						System.out.println("Exited");
						System.exit(0);
						
					default:
						System.out.println("Enter the digits 1, 2, or 3 only.");
						choiceFlag=false;
						break;
					}
					
				} catch (InputMismatchException e) {
					choiceFlag=false;
					System.out.println("Enter only digits.");
				}
			}while(!choiceFlag);
			scanner=new Scanner(System.in);
			System.out.println("Do you want to continue (Yes / No)");
			contiChoice=scanner.next();
		}while(contiChoice.equalsIgnoreCase("yes"));
		scanner.close();
	}

}
