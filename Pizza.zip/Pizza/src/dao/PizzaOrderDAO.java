package dao;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import bean.Customer;
import bean.PizzaOrder;
import exception.PizzaException;

public class PizzaOrderDAO implements IPizzaOrderDAO
{
	Map<Integer,PizzaOrder> pizzaEntry = new HashMap<Integer,PizzaOrder>();
	static Map<Integer, Customer> customerEntry = new HashMap<Integer, Customer>();
	@Override
	public int placeOrder(Customer customer, PizzaOrder pizza) throws PizzaException {
		int orderId=(int)(Math.random()*1000);
		int customerId=(int)(Math.random()*1000);
		
		pizza.setOrderId(orderId);
		pizza.setCustomerId(customerId);
		customer.setCustomerId(customerId);
		
		pizzaEntry.put(orderId, pizza);
		customerEntry.put(customerId, customer);
		
		return orderId;
	}

	@Override
	public PizzaOrder getOrderDetails(int orderid) throws PizzaException {
		PizzaOrder order=null;
		boolean flag =false;
		
		Set<Integer> set=pizzaEntry.keySet();
		
		for(int id : set)
		{
			
			if(id == orderid)
			{
				PizzaOrder order1=pizzaEntry.get(id);
				int customerId=order1.getCustomerId();
				
				Customer customer=customerEntry.get(customerId);
				order=pizzaEntry.get(id);
				break;
			}
			
		}
		
		if(order == null)
		{
			throw new PizzaException("No order present with this order Id.");
		}
		
		return order;
	}

	public  Customer getCustomer(int customerId) {
		Customer c1=null;
		for(Customer c:customerEntry.values()) {
			//System.out.println(c.getCustomerId());
			if(c.getCustomerId()==customerId) 
				c1=c;
			}
		//System.out.println(c1.getCustName()+c1.getAddress());
		return c1;
	}
	

}
