package dao;

import bean.Customer;
import bean.PizzaOrder;
import exception.PizzaException;

public interface IPizzaOrderDAO 
{
	public int placeOrder(Customer customer,PizzaOrder pizza) throws PizzaException;
	
	public PizzaOrder getOrderDetails(int orderid) throws PizzaException;
	
	
}
